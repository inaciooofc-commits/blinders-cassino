/**
 * BLINDERS CASSINO — ZARCOVI APPS SCRIPT SYNC
 *
 * Como usar:
 * 1. Abra a planilha Zarcovi.
 * 2. Extensões > Apps Script.
 * 3. Cole este código.
 * 4. Em Project Settings > Script Properties, crie:
 *    SUPABASE_URL = https://lbmmqfgcyimijaqnvvpx.supabase.co
 *    SUPABASE_ANON_KEY = SUA_ANON_KEY_DO_PROJETO
 *    BLINDERS_SYNC_SECRET = o mesmo segredo cadastrado no Supabase
 * 5. Execute syncZarcoviToBlinders().
 * 6. Crie um gatilho de tempo para rodar a cada 1, 5 ou 15 minutos.
 */

function syncZarcoviToBlinders() {
  const props = PropertiesService.getScriptProperties();

  const supabaseUrl = props.getProperty('SUPABASE_URL');
  const anonKey = props.getProperty('SUPABASE_ANON_KEY');
  const secret = props.getProperty('BLINDERS_SYNC_SECRET');

  if (!supabaseUrl || !anonKey || !secret) {
    throw new Error('Configure SUPABASE_URL, SUPABASE_ANON_KEY e BLINDERS_SYNC_SECRET nas Script Properties.');
  }

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheets()[0];
  const values = sheet.getDataRange().getDisplayValues();

  const accounts = extractZarcoviAccounts_(values);

  const payload = {
    p_secret: secret,
    p_source_key: 'banco01',
    p_source_url: ss.getUrl(),
    p_accounts: accounts
  };

  const response = UrlFetchApp.fetch(supabaseUrl + '/rest/v1/rpc/app_zarcovi_live_apps_script_push', {
    method: 'post',
    contentType: 'application/json',
    headers: {
      apikey: anonKey,
      Authorization: 'Bearer ' + anonKey
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  const code = response.getResponseCode();
  const body = response.getContentText();

  if (code < 200 || code >= 300) {
    throw new Error('Erro Supabase ' + code + ': ' + body);
  }

  Logger.log(body);
  return body;
}

function extractZarcoviAccounts_(rows) {
  const accounts = [];
  const seen = {};

  for (let r = 0; r < rows.length; r++) {
    const row = rows[r].map(v => String(v || '').trim());

    for (let c = 0; c < row.length - 1; c++) {
      if (row[c].toLowerCase() === 'vila' && row[c + 1].toUpperCase() === 'CONTA') {
        for (let k = r + 1; k < rows.length; k++) {
          const rr = rows[k] || [];
          const kind = String(rr[c] || '').trim();
          const conta = String(rr[c + 1] || '').trim().toUpperCase();

          if (!conta || conta === 'CONTA') continue;
          if (!/^[A-Z]{2,}[A-Z0-9]{1,}$/.test(conta)) continue;

          if (seen[conta]) continue;
          seen[conta] = true;

          accounts.push({
            sourceRow: k + 1,
            kind: kind || 'Conta',
            vila: kind || '',
            conta: conta,
            level: parseNumber_(rr[c + 2]),
            ryosB: parseNumber_(rr[c + 3]),
            salarioB: parseNumber_(rr[c + 4]),
            cargos: String(rr[c + 5] || '').trim(),
            fogo: parseNumber_(rr[c + 6]),
            pedra: parseNumber_(rr[c + 7]),
            personagem: String(rr[c + 8] || '').trim(),
            tesouroB: parseNumber_(rr[c + 9]),
            raw: rr.slice(c, c + 10)
          });
        }
      }
    }
  }

  return accounts;
}

function parseNumber_(value) {
  let s = String(value || '').trim();
  if (!s) return 0;

  s = s.replace(/[^\d,.\-]/g, '');
  if (!s || s === '-') return 0;

  if (s.indexOf(',') >= 0 && s.indexOf('.') >= 0) {
    s = s.replace(/\./g, '').replace(',', '.');
  } else if (s.indexOf(',') >= 0) {
    s = s.replace(',', '.');
  }

  const n = Number(s);
  return isFinite(n) ? n : 0;
}

function createEveryMinuteTrigger() {
  ScriptApp.newTrigger('syncZarcoviToBlinders')
    .timeBased()
    .everyMinutes(1)
    .create();
}
