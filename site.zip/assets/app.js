const SUPABASE_URL = 'https://lbmmqfgcyimijaqnvvpx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';

const TOKEN_KEY='BLINDERS_TOKEN_V25';
const MEMBER_KEY='BLINDERS_MEMBER_V25';
const PWA_DONT='BLINDERS_PWA_DONT_REMIND_V25';
let deferredPrompt = null;

function $(s){return document.querySelector(s)}
function $all(s){return [...document.querySelectorAll(s)]}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function token(){return localStorage.getItem(TOKEN_KEY)}
function member(){try{return JSON.parse(localStorage.getItem(MEMBER_KEY)||'null')}catch{return null}}
function saveSession(t,m){localStorage.setItem(TOKEN_KEY,t);localStorage.setItem(MEMBER_KEY,JSON.stringify(m||null))}
function status(msg,type=''){const b=$('#statusBox'); if(b){b.className='status '+type;b.innerHTML=msg}}
function go(path){location.href=path}
function cleanNext(value,fallback){try{let n=value||'';for(let i=0;i<5;i++){const d=decodeURIComponent(n);if(d===n)break;n=d}if(!n.startsWith('/'))return fallback;const u=new URL(n,location.origin);if(u.pathname.includes('/login')||u.pathname.includes('/register'))return fallback;return u.pathname+u.search}catch{return fallback}}
async function rpc(name, params={}){
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{'apikey':SUPABASE_ANON_KEY,'Authorization':`Bearer ${SUPABASE_ANON_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  let data=null; const text=await res.text();
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok){
    const msg = data?.message || data?.error_description || data?.hint || text || 'Erro no Supabase';
    throw new Error(msg);
  }
  return data;
}
function applyPrefs(){
  const lite=localStorage.getItem('BLINDERS_LITE_MODE')==='1';
  document.body.classList.toggle('lite',lite);
}
function requireLogin(admin=false){
  const m=member();
  if(!token()||!m){go(admin?'/owner/login.html':'/member/login.html');return null}
  if(admin && !['admin','owner'].includes(m.role)){go('/member/start.html');return null}
  return m;
}
function logout(){localStorage.removeItem(TOKEN_KEY);localStorage.removeItem(MEMBER_KEY);go('/member/login.html')}
window.BlindersLogout=logout;

function bootLogin(area='member'){
  $('#loginForm')?.addEventListener('submit', async e=>{
    e.preventDefault();
    const fd=new FormData(e.currentTarget);
    try{
      status('Entrando...');
      const data=await rpc('app_login_v25',{p_identifier:String(fd.get('identifier')||'').trim(),p_password:String(fd.get('password')||''),p_area:area,p_user_agent:navigator.userAgent});
      if(area==='owner'&&!['admin','owner'].includes(data.member?.role)) throw new Error('Acesso reservado para admin/dono.');
      saveSession(data.token,data.member);
      go(cleanNext(new URLSearchParams(location.search).get('next'), area==='owner'?'/owner/panel.html':'/member/start.html'));
    }catch(err){status(esc(err.message||'Erro ao entrar.'),'error')}
  });
}
function bootRegister(){
  $('#registerForm')?.addEventListener('submit', async e=>{
    e.preventDefault();
    const form=e.currentTarget;
    const fd=new FormData(form);
    try{
      status('Criando conta...');
      const data=await rpc('app_register_member_v25',{p_zarcovi_account:String(fd.get('zarcoviAccount')||'').trim(),p_nick:String(fd.get('nick')||'').trim(),p_password:String(fd.get('password')||''),p_user_agent:navigator.userAgent});
      status(`Conta criada.\n\nCódigo: ${esc(data.confirmationCode)}\nID IRIS: ${esc(data.irisMemberId)}\n\nEnvie o código para o admin confirmar.`, 'success');
      form.reset();
    }catch(err){status(`${esc(err.message||'Erro ao criar conta.')}\n\nRode o SQL V25 no Supabase e tente novamente.`,'error')}
  });
}
async function bootStart(){
  const m=requireLogin(); if(!m)return;
  $('#who') && ($('#who').textContent=`${m.nick||'Membro'} • ${m.role}`);
  try{
    const data=await rpc('app_v25_wallet',{p_token:token()});
    $('#balance') && ($('#balance').textContent=data.wallet.balanceLabel);
    $('#iris') && ($('#iris').textContent='ID IRIS: '+data.wallet.irisMemberId);
  }catch{ $('#balance') && ($('#balance').textContent='Erro') }
  showPwaPrompt();
}
function bootPanel(){
  const m=requireLogin(true); if(!m)return;
  $('#who') && ($('#who').textContent=`${m.nick||'Admin'} • ${m.role}`);
  $('#clearCacheBtn')?.addEventListener('click', async()=>{
    status('Limpando cache...');
    await clearCaches(false);
    status('Cache limpo sem apagar login.', 'success');
  });
  rpc('app_v25_admin_dashboard',{p_token:token()}).then(data=>{
    const s=data.summary||{};
    $('#adminCards').innerHTML=[
      ['Contas pendentes',s.pendingAccounts||0],
      ['Notificações',s.pendingNotifications||0],
      ['Transações hoje',s.transactionsToday||0],
      ['Reportes abertos',s.openReports||0]
    ].map(x=>`<article class="card"><h2>${x[0]}</h2><div class="kpi">${x[1]}</div></article>`).join('');
  }).catch(e=>status(esc(e.message),'error'));
}
async function clearCaches(removeSession=false){
  if('serviceWorker' in navigator){const regs=await navigator.serviceWorker.getRegistrations();await Promise.all(regs.map(r=>r.unregister()))}
  if('caches' in window){const keys=await caches.keys();await Promise.all(keys.map(k=>caches.delete(k)))}
  sessionStorage.clear();
  if(removeSession){localStorage.removeItem(TOKEN_KEY);localStorage.removeItem(MEMBER_KEY)}
}
function bootClear(){
  (async()=>{
    try{await clearCaches(false); status('Cache limpo. Agora abra Login ou Cadastro.','success')}
    catch{status('Não consegui limpar tudo automaticamente. Tente aba anônima.','error')}
  })();
}
function bootTransfer(){
  requireLogin();
  $('#transferForm')?.addEventListener('submit',async e=>{
    e.preventDefault(); const form=e.currentTarget; const fd=new FormData(form);
    try{
      status('Transferindo...');
      const data=await rpc('app_v25_transfer',{p_token:token(),p_to_iris_id:String(fd.get('toIris')||'').trim(),p_amount:String(fd.get('amount')||'').trim()});
      status(`Transferido.\nTX: ${esc(data.txCode)}\nAstral: ${esc(data.astralCode)}`,'success'); form.reset();
    }catch(err){status(esc(err.message),'error')}
  });
}
function bootBet(){
  requireLogin();
  const game=new URLSearchParams(location.search).get('game')||'roleta';
  $('#gameTitle') && ($('#gameTitle').textContent=game.toUpperCase());
  $('#betForm')?.addEventListener('submit',async e=>{
    e.preventDefault(); const fd=new FormData(e.currentTarget);
    try{
      status('Rodando aposta...');
      const data=await rpc('app_v25_play_game',{p_token:token(),p_game_key:game,p_amount:String(fd.get('amount')||'').trim()});
      const r=data.result;
      status(`${r.outcome==='win'?'Vitória':'Derrota'}\n${esc(r.message)}\nAposta: ${r.betLabel}\nPrêmio: ${r.prizeLabel}\nSaldo: ${r.balanceLabel}\nTX: ${r.txCode}\nAstral: ${r.astralCode}`, r.outcome==='win'?'success':'error');
    }catch(err){status(esc(err.message),'error')}
  });
}
function txCard(t){
  return `<article class="card"><h2>${esc(t.type||'Transação')}</h2><div class="code">TX: ${esc(t.txCode||'')}</div><div class="code">Astral: ${esc(t.astralCode||'')}</div><div class="row"><span>Valor</span><b>${esc(t.amountLabel||'')}</b></div><div class="row"><span>Status</span><b>${esc(t.status||'')}</b></div><div class="row"><span>Origem</span><b>${esc(t.fromIrisId||'-')}</b></div><div class="row"><span>Destino</span><b>${esc(t.toIrisId||'-')}</b></div><p class="code">${esc(t.createdAt||'')}</p></article>`;
}
function bootHistory(admin=false){
  if(admin) requireLogin(true); else requireLogin();
  async function load(){
    const data=await rpc(admin?'app_v25_admin_transactions':'app_v25_member_history',{p_token:token(),p_type:$('#typeFilter')?.value||'',p_status:$('#statusFilter')?.value||''});
    const rows=data.transactions||[];
    $('#list').innerHTML=rows.map(txCard).join('')||'<article class="card"><h2>Sem registros</h2></article>';
  }
  $('#filterBtn')?.addEventListener('click',load); load().catch(e=>$('#list').innerHTML=`<article class="card"><h2>Erro</h2><p>${esc(e.message)}</p></article>`);
}
function bootDeposit(){
  requireLogin();
  $('#depositForm')?.addEventListener('submit',async e=>{
    e.preventDefault(); const form=e.currentTarget; const fd=new FormData(form);
    try{
      status('Enviando pedido...');
      const file=$('#receiptFile')?.files?.[0]; let receipt='';
      if(file){ if(file.size>3500000) throw new Error('Print muito grande. Use até 3.5MB.'); receipt=await new Promise((ok,fail)=>{const r=new FileReader();r.onload=()=>ok(String(r.result||''));r.onerror=fail;r.readAsDataURL(file)})}
      const data=await rpc('app_v25_create_deposit_request',{p_token:token(),p_amount:String(fd.get('amount')||'').trim(),p_payer_account:String(fd.get('payerAccount')||'').trim(),p_receipt_data_url:receipt});
      status(`Depósito enviado.\nTX: ${esc(data.txCode)}\nAstral: ${esc(data.astralCode)}`,'success'); form.reset();
    }catch(err){status(esc(err.message),'error')}
  });
}
function bootWithdraw(){
  requireLogin();
  $('#withdrawForm')?.addEventListener('submit',async e=>{
    e.preventDefault(); const form=e.currentTarget; const fd=new FormData(form);
    try{
      status('Solicitando saque...');
      const data=await rpc('app_v25_create_withdraw_request',{p_token:token(),p_amount:String(fd.get('amount')||'').trim(),p_target_account:String(fd.get('targetAccount')||'').trim(),p_withdraw_link:String(fd.get('withdrawLink')||'').trim()});
      status(`Saque solicitado.\nTX: ${esc(data.txCode)}\nAstral: ${esc(data.astralCode)}\nCódigo: ${esc(data.withdrawCode)}`,'success'); form.reset();
    }catch(err){status(esc(err.message),'error')}
  });
}
function bootNotifications(){
  requireLogin(true);
  async function load(){
    const data=await rpc('app_v25_admin_notifications',{p_token:token()});
    const rows=data.notifications||[];
    $('#list').innerHTML=rows.map(n=>`<article class="card"><h2>${esc(n.title)}</h2><p>${esc(n.body)}</p><div class="code">TX: ${esc(n.txCode||'')}</div><div class="code">Astral: ${esc(n.astralCode||'')}</div>${n.kind==='deposit'?`<button class="btn" data-dep="${esc(n.requestId)}">Confirmar depósito</button>`:''}${n.kind==='withdraw'?`<label>Código<input data-code="${esc(n.requestId)}"></label><button class="btn" data-wit="${esc(n.requestId)}">Confirmar saque</button>`:''}${n.kind==='report'?'<span class="badge">Reporte</span>':''}</article>`).join('')||'<article class="card"><h2>Nada pendente</h2></article>';
  }
  document.addEventListener('click',async e=>{
    const dep=e.target?.dataset?.dep, wit=e.target?.dataset?.wit;
    try{
      if(dep){await rpc('app_v25_admin_confirm_deposit',{p_token:token(),p_request_id:dep}); load()}
      if(wit){const c=document.querySelector(`[data-code="${CSS.escape(wit)}"]`)?.value||''; await rpc('app_v25_admin_confirm_withdraw',{p_token:token(),p_request_id:wit,p_code:c}); load()}
    }catch(err){alert(err.message)}
  });
  load();
}
function bootShop(){
  requireLogin();
  rpc('app_v25_shop_items',{p_token:token()}).then(data=>{
    $('#list').innerHTML=(data.items||[]).map(i=>`<article class="card"><h2>${esc(i.name)}</h2><p>${esc(i.description)}</p><div class="row"><span>Raridade</span><b>${esc(i.rarity)}</b></div><div class="row"><span>Preço</span><b>${esc(i.priceLabel)}</b></div></article>`).join('');
  }).catch(e=>$('#list').innerHTML=`<article class="card"><h2>Erro</h2><p>${esc(e.message)}</p></article>`);
}
function bootAchievements(){
  requireLogin();
  async function load(){
    const data=await rpc('app_v25_member_achievements',{p_token:token()});
    $('#list').innerHTML=(data.achievements||[]).map(a=>`<article class="card"><h2>${esc(a.name)}</h2><p>${esc(a.description)}</p><div class="row"><span>Status</span><b>${a.completed?'Completa':'Pendente'}</b></div><div class="row"><span>Recompensa</span><b>${esc(a.rewardLabel)}</b></div></article>`).join('');
  }
  $('#claimDaily')?.addEventListener('click',async()=>{try{const d=await rpc('app_v25_claim_daily_reward',{p_token:token()});status(`Recompensa: ${d.rewardLabel}`,'success');load()}catch(e){status(esc(e.message),'error')}});
  load().catch(e=>status(esc(e.message),'error'));
}
function bootPreferences(){
  requireLogin();
  $('#liteMode').checked=localStorage.getItem('BLINDERS_LITE_MODE')==='1';
  $('#prefsForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    localStorage.setItem('BLINDERS_LITE_MODE',$('#liteMode').checked?'1':'0');
    applyPrefs();
    try{await rpc('app_v25_save_preferences',{p_token:token(),p_preferences:{liteMode:$('#liteMode').checked}});status('Preferências salvas.','success')}catch{status('Preferência local salva.','success')}
  });
}
function bootReport(){
  requireLogin();
  $('#reportForm')?.addEventListener('submit',async e=>{
    e.preventDefault(); const form=e.currentTarget; const fd=new FormData(form);
    try{
      const data=await rpc('app_v25_report_problem',{p_token:token(),p_title:String(fd.get('title')||'').trim(),p_description:String(fd.get('description')||'').trim(),p_page_url:location.href,p_user_agent:navigator.userAgent});
      status(`Reporte enviado.\nCódigo: ${data.reportCode}`,'success'); form.reset();
    }catch(err){status(esc(err.message),'error')}
  });
}
function bootStatus(){
  requireLogin(true);
  rpc('app_v25_system_status',{p_token:token()}).then(data=>{
    const s=data.status||{}; $('#list').innerHTML=Object.keys(s).map(k=>`<article class="card"><h2>${esc(k)}</h2><p>${esc(s[k])}</p></article>`).join('');
  }).catch(e=>$('#list').innerHTML=`<article class="card"><h2>Erro</h2><p>${esc(e.message)}</p></article>`);
}
function bootReports(){
  requireLogin(true);
  rpc('app_v25_admin_reports',{p_token:token()}).then(data=>{
    $('#list').innerHTML=(data.reports||[]).map(r=>`<article class="card"><h2>${esc(r.title)}</h2><p>${esc(r.description)}</p><div class="code">${esc(r.reportCode)}</div></article>`).join('')||'<article class="card"><h2>Sem reportes</h2></article>';
  });
}
function bootLogs(){
  requireLogin(true);
  rpc('app_v25_error_logs',{p_token:token()}).then(data=>{
    $('#list').innerHTML=(data.logs||[]).map(l=>`<article class="card"><h2>${esc(l.level)}</h2><p>${esc(l.message)}</p><div class="code">${esc(l.createdAt)}</div></article>`).join('')||'<article class="card"><h2>Sem erros</h2></article>';
  });
}
function showPwaPrompt(){
  if(localStorage.getItem(PWA_DONT)==='1')return;
  if(matchMedia('(display-mode: standalone)').matches)return;
  const box=$('#pwaBox'); if(!box)return;
  box.classList.remove('hidden');
}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e});
async function installPwa(){
  if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice.catch(()=>null);deferredPrompt=null;$('#pwaBox')?.classList.add('hidden')}
  else go('/install.html');
}
function bootInstall(){ $('#installBtn')?.addEventListener('click',installPwa); $('#dontBtn')?.addEventListener('click',()=>{localStorage.setItem(PWA_DONT,'1');$('#pwaBox')?.classList.add('hidden')}) }

document.addEventListener('DOMContentLoaded',()=>{
  applyPrefs();
  const page=document.body.dataset.page||'';
  if(page==='login')bootLogin('member');
  if(page==='owner-login')bootLogin('owner');
  if(page==='register')bootRegister();
  if(page==='start')bootStart();
  if(page==='panel')bootPanel();
  if(page==='clear')bootClear();
  if(page==='transfer')bootTransfer();
  if(page==='bet')bootBet();
  if(page==='deposit')bootDeposit();
  if(page==='withdraw')bootWithdraw();
  if(page==='notifications')bootNotifications();
  if(page==='shop')bootShop();
  if(page==='history')bootHistory(false);
  if(page==='admin-transactions')bootHistory(true);
  if(page==='achievements')bootAchievements();
  if(page==='preferences')bootPreferences();
  if(page==='report')bootReport();
  if(page==='status')bootStatus();
  if(page==='reports')bootReports();
  if(page==='logs')bootLogs();
  bootInstall();
});
