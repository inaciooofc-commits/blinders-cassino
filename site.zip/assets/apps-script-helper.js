/*
  Blinders 0.3.5 — helper visual do Apps Script.
*/
document.addEventListener('DOMContentLoaded',()=>{
  if(document.body.dataset.page!=='apps-script-sync') return;
  const btn=document.querySelector('#copyAppsScriptBtn');
  const code=document.querySelector('#appsScriptCode');
  btn?.addEventListener('click',async()=>{
    try{
      await navigator.clipboard.writeText(code.textContent);
      const s=document.querySelector('#statusBox');
      if(s){s.className='status success';s.textContent='Código copiado.'}
    }catch(e){
      const s=document.querySelector('#statusBox');
      if(s){s.className='status error';s.textContent='Não consegui copiar automaticamente. Selecione e copie manualmente.'}
    }
  });
});
