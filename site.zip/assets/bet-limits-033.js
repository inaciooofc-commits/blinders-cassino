
/*
  Blinders 0.3.3 — limites oficiais de aposta.
  Mínimo: 1500B / 1,5T. Máximo: 3T.
*/
(function(){
  document.addEventListener('DOMContentLoaded', function(){
    const boxes = document.querySelectorAll('#gameRule, .official-warning, .stable-clean-note');
    boxes.forEach(function(b){
      if(!b.dataset.limitPatch){
        b.dataset.limitPatch='1';
        b.insertAdjacentHTML('beforeend','<p><strong>Limite oficial:</strong> aposta mínima 1500B / 1,5T e aposta máxima 3T.</p>');
      }
    });
    document.querySelectorAll('input[name="amount"]').forEach(function(inp){
      inp.placeholder='1500B até 3T';
    });
  });
})();
