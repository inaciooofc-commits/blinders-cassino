/*
  BLINDERS EFFECTS — GitHub Ready
  Reveal, ripple, sidebar fluida, classes automáticas e limpeza visual.
*/
(function(){
  let initialized=false;

  function qsAll(sel,root=document){return Array.from(root.querySelectorAll(sel));}

  function applyPremiumClasses(){
    qsAll('.card,.box,.panel,.modal,.popup,.notice,.alert,.status,.official-option,.official-kpi,.con037-menu-item,.iris-card,.iris-control-kpi,.supabase-action,.zarcovi-live-card,.real-game-board')
      .forEach(el=>{el.classList.add('blinders-card','reveal');});

    qsAll('a[href*="/play/game"], .game-card, .menu-tile[href*="/play"], .icon-card[href*="/play"]')
      .forEach(el=>{el.classList.add('game-card','blinders-card','reveal','glow-border');});

    qsAll('.btn,button,input[type="submit"]')
      .forEach(el=>el.classList.add('blinders-btn'));

    qsAll('input,select,textarea')
      .forEach(el=>el.classList.add('blinders-input'));

    qsAll('main,section,.app,.top')
      .forEach(el=>el.classList.add('reveal'));

    qsAll('img').forEach(img=>{
      if(!img.hasAttribute('loading')) img.setAttribute('loading','lazy');
      if(!img.hasAttribute('decoding')) img.setAttribute('decoding','async');
    });
  }

  function initRevealEffects(){
    const items=qsAll('.reveal');
    if(!('IntersectionObserver' in window)){
      items.forEach(el=>el.classList.add('visible'));
      return;
    }
    const io=new IntersectionObserver((entries)=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){
          entry.target.classList.add('visible');
          io.unobserve(entry.target);
        }
      });
    },{threshold:.08,rootMargin:'0px 0px -30px 0px'});
    items.forEach(el=>io.observe(el));
  }

  function initRippleButtons(){
    document.addEventListener('click',function(e){
      const btn=e.target.closest('.blinders-btn');
      if(!btn) return;
      const rect=btn.getBoundingClientRect();
      const size=Math.max(rect.width,rect.height);
      const ripple=document.createElement('span');
      ripple.className='blinders-ripple';
      ripple.style.width=ripple.style.height=size+'px';
      ripple.style.left=(e.clientX-rect.left-size/2)+'px';
      ripple.style.top=(e.clientY-rect.top-size/2)+'px';
      btn.appendChild(ripple);
      setTimeout(()=>ripple.remove(),650);
    },{passive:true});
  }

  function findSidebar(){
    return document.querySelector('.sidebar,.engtech-sidebar,.side,aside.sidebar,aside[class*="sidebar"]');
  }

  function findHamburger(){
    return document.querySelector('.hamburger,.menu-toggle,#hamburger,[data-menu-toggle],button[aria-label*="menu" i],button[aria-label*="Menu" i]');
  }

  function initSidebarFluid(){
    const sidebar=findSidebar();
    const hamburger=findHamburger();
    if(!sidebar || !hamburger) return;

    hamburger.classList.add('hamburger');
    if(!sidebar.classList.contains('sidebar')) sidebar.classList.add('sidebar');

    hamburger.addEventListener('click',function(){
      sidebar.classList.toggle('closed');
      hamburger.classList.toggle('active');
      document.body.classList.toggle('sidebar-closed',sidebar.classList.contains('closed'));
    });
  }

  function initPageTransition(){
    document.body.classList.add('page-transition');
  }

  function cleanCommonUserDebug(){
    let member=null;
    try{member=JSON.parse(localStorage.getItem('BLINDERS_MEMBER_V25')||'null')}catch(e){}
    const isAdmin=member && ['admin','owner'].includes(member.role);
    if(isAdmin) return;
    qsAll('[data-admin-only],.admin-only,.debug,[data-debug],.system-debug,.dev-info,.sql-info,.version-info,.engine-label,.tech-label')
      .forEach(el=>el.remove());
  }

  function boot(){
    if(initialized) return;
    initialized=true;
    initPageTransition();
    applyPremiumClasses();
    cleanCommonUserDebug();
    initRevealEffects();
    initRippleButtons();
    initSidebarFluid();

    setTimeout(()=>{applyPremiumClasses();cleanCommonUserDebug();initRevealEffects();},500);
    setTimeout(()=>{applyPremiumClasses();cleanCommonUserDebug();},1400);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot);
  else boot();

  window.BlindersEffects={boot,applyPremiumClasses,initRevealEffects,initRippleButtons,initSidebarFluid};
})();
