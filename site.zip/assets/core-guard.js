(function(){
  const URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
  const KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
  const TOKEN='BLINDERS_TOKEN_V25';
  function token(){return localStorage.getItem(TOKEN)||''}
  async function rpc(name,params={}){try{await fetch(`${URL}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:KEY,Authorization:`Bearer ${KEY}`,'Content-Type':'application/json'},body:JSON.stringify(params)})}catch(e){}}
  function report(category,message,meta={}){rpc('app_malena_report_error',{p_token:token(),p_category:category,p_message:String(message||''),p_route:location.pathname+location.search,p_metadata:meta})}
  window.addEventListener('error',e=>report('javascript',e.message||'Erro JS',{filename:e.filename||'',lineno:e.lineno||0,colno:e.colno||0}));
  window.addEventListener('unhandledrejection',e=>report('promise',e.reason?.message||String(e.reason||'Promise rejeitada'),{reason:String(e.reason||'')}));
  document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>rpc('app_malena_ping',{p_token:token(),p_route:location.pathname,p_user_agent:navigator.userAgent||'',p_width:window.innerWidth,p_height:window.innerHeight}),1200));
})();
