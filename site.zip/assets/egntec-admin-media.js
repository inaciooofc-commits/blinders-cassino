const MEDIA_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const MEDIA_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const MEDIA_TOKEN='BLINDERS_TOKEN_V25';
function mt(){return localStorage.getItem(MEDIA_TOKEN)}
function me(){try{return JSON.parse(localStorage.getItem('BLINDERS_MEMBER_V25')||'null')}catch{return null}}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function st(m,t=''){const b=document.querySelector('#statusBox');if(b){b.className='status '+t;b.innerHTML=m}}
async function rpc(name, params={}){
  const res=await fetch(`${MEDIA_URL}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:MEDIA_KEY,Authorization:`Bearer ${MEDIA_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(params)});
  const text=await res.text();let data=null;try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok)throw new Error(data?.message||text||'Erro');
  return data;
}
function requireAdmin(){const m=me();if(!m||!['admin','owner'].includes(m.role)){location.href='/owner/login.html';return null}return m}
async function fileData(input, max=5500000){
  const f=input.files?.[0]; if(!f)return '';
  if(f.size>max)throw new Error('Arquivo muito grande. Use até 5.5MB.');
  return await new Promise((ok,fail)=>{const r=new FileReader();r.onload=()=>ok(String(r.result||''));r.onerror=fail;r.readAsDataURL(f)});
}
function bootAdminMedia(){
  requireAdmin();
  document.querySelector('#mediaForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    try{
      st('Salvando mídia...');
      const radio=await fileData(document.querySelector('#radioFile'));
      const soundtrack=await fileData(document.querySelector('#soundtrackFile'));
      const bg=await fileData(document.querySelector('#backgroundFile'));
      await rpc('app_v33_admin_save_media',{p_token:mt(),p_radio_data_url:radio,p_soundtrack_data_url:soundtrack,p_background_data_url:bg,p_radio_name:document.querySelector('#radioName').value||'Rádio Blinders'});
      st('Mídia salva. Reabra o site para aplicar em todas as páginas.','success');
    }catch(err){st(esc(err.message),'error')}
  });
}
function bootIconpack(){
  requireAdmin();
  const icons=['royal-crown','gold-chip','iris-bank','dragon-guard','lucky-seven','ace-card','roulette-star','bingo-ball','dice-master','radio-note','shadow-mask','red-diamond','green-club','gold-heart','black-spade','trophy','flame','moon','sun','shield'];
  document.querySelector('#iconList').innerHTML=icons.map(i=>`<button class="egntec-icon-choice" data-icon="${i}"><img src="/assets/iconpack/${i}.svg"><span>${i}</span></button>`).join('');
  document.addEventListener('click',async e=>{
    const icon=e.target.closest('[data-icon]')?.dataset?.icon;
    if(!icon)return;
    try{
      await rpc('app_v33_admin_save_iconpack',{p_token:mt(),p_iconpack_key:icon});
      st(`Iconpack aplicado: ${esc(icon)}`,'success');
    }catch(err){st(esc(err.message),'error')}
  });
}
async function applySiteMedia(){
  try{
    const data=await rpc('app_v33_get_media',{});
    const m=data.media||{};
    if(m.backgroundDataUrl){
      document.body.style.backgroundImage=`linear-gradient(rgba(0,0,0,.58),rgba(0,0,0,.78)), url("${m.backgroundDataUrl}")`;
      document.body.style.backgroundSize='cover';
      document.body.style.backgroundAttachment='fixed';
    }
    if((m.soundtrackDataUrl||m.radioDataUrl) && !document.querySelector('#egntecPlayer')){
      const box=document.createElement('section');
      box.id='egntecPlayer';
      box.className='egntec-player';
      box.innerHTML=`<strong>${esc(m.radioName||'Rádio Blinders')}</strong><audio controls loop preload="none" src="${esc(m.soundtrackDataUrl||m.radioDataUrl)}"></audio>`;
      document.body.appendChild(box);
    }
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>{applySiteMedia()});
window.EGNTechAdminMedia={bootAdminMedia,bootIconpack,applySiteMedia};
