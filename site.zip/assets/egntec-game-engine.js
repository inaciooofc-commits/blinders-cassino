const EGN_SUPABASE_URL = 'https://lbmmqfgcyimijaqnvvpx.supabase.co';
const EGN_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const EGN_TOKEN='BLINDERS_TOKEN_V25';
const EGN_MEMBER='BLINDERS_MEMBER_V25';

function egnToken(){return localStorage.getItem(EGN_TOKEN)}
function egnMember(){try{return JSON.parse(localStorage.getItem(EGN_MEMBER)||'null')}catch{return null}}
function egnEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function egnStatus(msg,type=''){const b=document.querySelector('#statusBox'); if(b){b.className='status '+type;b.innerHTML=msg}}
async function egnRpc(name, params={}){
  const res = await fetch(`${EGN_SUPABASE_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{'apikey':EGN_SUPABASE_ANON_KEY,'Authorization':`Bearer ${EGN_SUPABASE_ANON_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text(); let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok) throw new Error(data?.message || data?.hint || text || 'Erro no Supabase');
  return data;
}
function requireEgnLogin(admin=false){
  const m=egnMember();
  if(!egnToken()||!m){location.href=admin?'/owner/login.html':'/member/login.html';return null}
  if(admin&&!['admin','owner'].includes(m.role)){location.href='/member/start.html';return null}
  return m;
}
function stage(game){
  const map={
    roleta:`<div class="egntec-wheel"><span>0</span></div>`,
    blackjack:`<div class="egntec-cards"><div class="egntec-card">A♠</div><div class="egntec-card">K♦</div><div class="egntec-card">7♣</div></div>`,
    dados:`<div class="egntec-dice">⚂</div>`,
    bingo:`<div class="egntec-bingo"><div class="egntec-ball">B7</div><div class="egntec-ball">I12</div><div class="egntec-ball">N31</div><div class="egntec-ball">G48</div><div class="egntec-ball">O65</div></div>`,
    slots:`<div class="egntec-slots"><div class="egntec-reel">7</div><div class="egntec-reel">★</div><div class="egntec-reel">B</div></div>`,
    crash:`<div class="egntec-dice">🚀</div>`,
    memoria:`<div class="egntec-cards"><div class="egntec-card">✦</div><div class="egntec-card">✦</div><div class="egntec-card">?</div></div>`
  };
  return `<section class="egntec-stage">${map[game]||map.slots}</section>`;
}
function gameLabel(g){return ({roleta:'Roleta',blackjack:'Blackjack',dados:'Dados',bingo:'Bingo',slots:'Slots',crash:'Crash',memoria:'Memória'}[g]||g)}

function bootTables(){
  requireEgnLogin();
  const list=document.querySelector('#tableList');
  const form=document.querySelector('#createTableForm');
  async function load(){
    try{
      const data=await egnRpc('app_v33_list_tables',{p_token:egnToken()});
      const rows=data.tables||[];
      list.innerHTML=rows.map(t=>`<article class="card">
        <h2>${egnEsc(t.tableName)}</h2>
        <p>${egnEsc(gameLabel(t.gameKey))} • ${egnEsc(t.status)} • ${t.players}/${t.maxPlayers}</p>
        <div class="code">Mestre: ${egnEsc(t.masterName||'-')}</div>
        <a class="btn" href="/play/table.html?id=${egnEsc(t.id)}&game=${egnEsc(t.gameKey)}">Entrar</a>
      </article>`).join('') || '<article class="card"><h2>Sem mesas</h2><p>Crie uma mesa ou jogue solo.</p></article>';
    }catch(e){list.innerHTML=`<article class="card"><h2>Erro</h2><p>${egnEsc(e.message)}</p></article>`}
  }
  form?.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(form);
    try{
      egnStatus('Criando mesa...');
      const data=await egnRpc('app_v33_create_table',{p_token:egnToken(),p_game_key:String(fd.get('game')||'blackjack'),p_table_name:String(fd.get('tableName')||'Mesa Blinders')});
      egnStatus('Mesa criada. Abrindo...', 'success');
      location.href=`/play/table.html?id=${data.tableId}&game=${data.gameKey}`;
    }catch(err){egnStatus(egnEsc(err.message),'error')}
  });
  load();
}

function bootTable(){
  requireEgnLogin();
  const params=new URLSearchParams(location.search);
  const tableId=params.get('id');
  const game=params.get('game')||'blackjack';
  document.querySelector('#gameStage').innerHTML=stage(game);
  document.querySelector('#tableTitle').textContent=`Mesa ${gameLabel(game)}`;
  const info=document.querySelector('#tableInfo');
  const seats=document.querySelector('#seatList');
  async function load(){
    if(!tableId){info.innerHTML='Mesa não encontrada.';return}
    const data=await egnRpc('app_v33_get_table',{p_token:egnToken(),p_table_id:tableId});
    const t=data.table||{};
    info.innerHTML=`<span class="badge">${egnEsc(t.status)}</span> <span class="badge">${egnEsc(t.players)}/${egnEsc(t.maxPlayers)} jogadores</span> <span class="badge">${t.requiresMaster?'Com mestre':'Solo/CPU'}</span>`;
    seats.innerHTML=(t.seats||[]).map(s=>`<article class="egntec-seat">
      <h2>${egnEsc(s.nick)}</h2>
      <p>${egnEsc(s.betLabel||'Sem aposta')} • ${egnEsc(s.betStatus)}</p>
      <div class="code">${egnEsc(s.irisId||'')}</div>
      ${s.betStatus==='pending'&&t.canMaster?`<button class="btn" data-accept="${s.playerId}">Aceitar aposta</button>`:''}
    </article>`).join('') || '<article class="egntec-seat"><h2>Aguardando jogadores</h2></article>';
    if(t.result) document.querySelector('#resultBox').innerHTML=`<pre class="status success">${egnEsc(JSON.stringify(t.result,null,2))}</pre>`;
  }
  document.querySelector('#joinForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(e.currentTarget);
    try{
      egnStatus('Entrando na mesa...');
      await egnRpc('app_v33_join_table',{p_token:egnToken(),p_table_id:tableId,p_amount:String(fd.get('amount')||'1B')});
      egnStatus('Aposta enviada para a mesa.', 'success');
      load();
    }catch(err){egnStatus(egnEsc(err.message),'error')}
  });
  document.addEventListener('click',async e=>{
    const accept=e.target?.dataset?.accept;
    try{
      if(accept){
        await egnRpc('app_v33_accept_bet',{p_token:egnToken(),p_table_id:tableId,p_player_id:accept});
        load();
      }
      if(e.target?.id==='startTableBtn'){
        await egnRpc('app_v33_start_table',{p_token:egnToken(),p_table_id:tableId});
        load();
      }
    }catch(err){alert(err.message)}
  });
  load();
}

function bootSolo(){
  requireEgnLogin();
  const game=new URLSearchParams(location.search).get('game')||'slots';
  document.querySelector('#gameStage').innerHTML=stage(game);
  document.querySelector('#gameTitle').textContent=`${gameLabel(game)} Solo`;
}

window.EGNTechGameEngine={bootTables,bootTable,bootSolo,stage};

/* V34 extra animations and casino table rules UI */
(function(){
  const oldStage = window.EGNTechGameEngine?.stage;
  function v34Stage(game){
    const extra = {
      crash:`<section class="egntec-stage"><div class="egntec-crash-rocket">🚀</div><div class="egntec-cpu-bot">CPU</div></section>`,
      memoria:`<section class="egntec-stage"><div class="egntec-memory-grid">${Array.from({length:8}).map((_,i)=>`<div class="egntec-memory-cell">${i%2?'✦':'?'}</div>`).join('')}</div></section>`,
      solo:`<section class="egntec-stage"><div class="egntec-cpu-bot">CPU</div><div class="egntec-slots"><div class="egntec-reel">7</div><div class="egntec-reel">B</div><div class="egntec-reel">★</div></div></section>`
    };
    if(extra[game]) return extra[game];
    return oldStage ? oldStage(game) : `<section class="egntec-stage"><div class="egntec-cpu-bot">CPU</div></section>`;
  }
  if(window.EGNTechGameEngine){
    window.EGNTechGameEngine.stage = v34Stage;
  }
})();
