/*
  ENGTech Render Engine V30
  Motor de interface do Blinders Cassino:
  - injeta sidebar/hambúrguer
  - organiza rotas
  - reduz travamentos
  - controla modo leve
  - mantém páginas em harmonia
*/
(function(){
  const TOKEN_KEY='BLINDERS_TOKEN_V25';
  const MEMBER_KEY='BLINDERS_MEMBER_V25';
  const SIDEBAR_KEY='BLINDERS_SIDEBAR_CLOSED_V30';

  function getMember(){
    try{return JSON.parse(localStorage.getItem(MEMBER_KEY)||'null')}catch{return null}
  }
  function hasSession(){return !!localStorage.getItem(TOKEN_KEY)}
  function isAdmin(m){return !!m && ['admin','owner'].includes(m.role)}
  function isAuthPage(){
    const p=location.pathname;
    return p.includes('/login') || p.includes('/register') || p.includes('/clear') || p==='/' || p.endsWith('/index.html') && !hasSession();
  }
  function icon(name){return `/assets/ui/icons/${name}.svg`}
  function navItem(href,label,iconName){
    const active = location.pathname === href || location.pathname.startsWith(href.replace('index.html',''));
    return `<a class="${active?'is-active':''}" href="${href}"><img src="${icon(iconName)}" alt=""> <span>${label}</span></a>`;
  }
  function buttonLogout(){
    return `<button type="button" data-engtech-logout><img src="${icon('settings')}" alt=""> <span>Sair</span></button>`;
  }
  function buildNav(m){
    const memberNav=[
      ['/member/start.html','Início','home'],
      ['/play/index.html','Jogos','games'],
      ['/play/tables.html','Mesas','games'],
      ['/iris/index.html','Banco IRIS','iris'],
      ['/iris/transfer.html','Transferir','transfer'],
      ['/iris/deposit.html','Depositar','deposit'],
      ['/iris/withdraw.html','Sacar','withdraw'],
      ['/shop/index.html','Loja','shop'],
      ['/member/history.html','Histórico','history'],
      ['/member/achievements.html','Conquistas','achievements'],
      ['/member/preferences.html','Modo leve','settings'],
      ['/member/report-problem.html','Reportar','report'],
      ['/member/chat.html','Chat','bell'],
      ['/member/status.html','Meu status','status'],
      ['/events/index.html','Eventos','shop'],
      ['/leaderboard/index.html','Ranking','achievements'],
      ['/member/inventory.html','Inventário','shop'],
      ['/member/bonus.html','Bônus','shop'],
      ['/member/change-password.html','Trocar senha','settings'],
      ['/rules/index.html','Regras','history'],
      ['/clans/index.html','Clãs','admin'],
    ];
    const adminNav=[
      ['/owner/panel.html','Painel','admin'],
      ['/owner/iris-control.html','IRIS Control','iris'],
      ['/owner/consolidated-sync.html','Sync App','history'],
      ['/owner/transfer-log.html','Transferências','iris'],
      ['/owner/guest-sheet-sync.html','Planilha Convidado','history'],
      ['/owner/apps-script-sync.html','Apps Script','settings'],
      ['/owner/zarcovi-sync.html','Zarcovi Sync','history'],
      ['/owner/supabase-control.html','Supabase','settings'],
      ['/owner/official-dashboard.html','Painel oficial','status'],
      ['/owner/backups.html','Backups','settings'],
      ['/owner/health.html','Saúde','status'],
      ['/owner/reports-center.html','Relatórios','history'],
      ['/owner/audit.html','Auditoria','logs'],
      ['/owner/admin-menu.html','Menu ADM','admin'],
      ['/owner/create-account.html','Criar conta','admin'],
      ['/owner/system-control.html','Sistema','settings'],
      ['/owner/sangria.html','Sangria','iris'],
      ['/owner/bonus-codes.html','Bônus','shop'],
      ['/owner/delete-accounts.html','Excluir contas','report'],
      ['/owner/vault.html','Cofre','iris'],
      ['/owner/admin-center.html','Central Admin','admin'],
      ['/owner/notifications.html','Notificações','bell'],
      ['/owner/transactions.html','Transações','history'],
      ['/owner/system-status.html','Status','status'],
      ['/owner/reports.html','Reportes','report'],
      ['/owner/error-logs.html','Logs','logs'],
      ['/owner/media.html','Mídia','settings'],
      ['/owner/iconpack.html','IconPack','shop'],
      ['/owner/shop-limit.html','Loja Admin','shop'],
    ];
    let html = memberNav.map(x=>navItem(...x)).join('');
    if(isAdmin(m)){
      html += `<div class="engtech-admin-sep"></div>`;
      html += adminNav.map(x=>navItem(...x)).join('');
    }
    html += `<div class="engtech-admin-sep"></div>${buttonLogout()}`;
    return html;
  }
  function logout(){
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(MEMBER_KEY);
    location.href='/member/login.html';
  }
  function applyPerformance(){
    const lite = localStorage.getItem('BLINDERS_LITE_MODE') === '1';
    document.body.classList.toggle('lite', lite);

    // Android / telas fracas: reduz movimento automaticamente, mas sem bloquear visual
    const low = window.innerWidth < 520 || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
    document.body.classList.toggle('engtech-low-power', !!low);
  }
  function mount(){
    applyPerformance();

    if(isAuthPage()){
      document.body.classList.add('engtech-auth');
      return;
    }

    const m=getMember();
    if(!m && !location.pathname.includes('/member/login')){
      // Não força se a página já tiver gate próprio, apenas não injeta sidebar
      return;
    }

    document.body.classList.add('engtech-ready');

    const closed = localStorage.getItem(SIDEBAR_KEY)==='1';
    const mobile = window.innerWidth <= 860;
    document.body.classList.toggle('engtech-mobile', mobile);
    document.body.classList.toggle('engtech-sidebar-closed', mobile ? true : closed);

    const sidebar=document.createElement('aside');
    sidebar.className='engtech-sidebar';
    sidebar.innerHTML=`
      <div class="engtech-brand">
        <img src="/assets/pwa/icon-192.png" alt="B">
        <div><strong>BLINDERS</strong><span>${m?.nick||'Membro'} • ${m?.role||'user'}</span></div>
      </div>
      <nav class="engtech-nav">${buildNav(m)}</nav>
    `;

    const btn=document.createElement('button');
    btn.className='engtech-hamburger';
    btn.type='button';
    btn.setAttribute('aria-label','Abrir menu');
    btn.textContent='☰';

    const overlay=document.createElement('div');
    overlay.className='engtech-overlay';

    document.body.prepend(overlay);
    document.body.prepend(sidebar);
    document.body.prepend(btn);

    function toggle(){
      const isClosed=document.body.classList.toggle('engtech-sidebar-closed');
      if(!document.body.classList.contains('engtech-mobile')){
        localStorage.setItem(SIDEBAR_KEY, isClosed?'1':'0');
      }
    }

    btn.addEventListener('click', toggle);
    overlay.addEventListener('click', ()=>document.body.classList.add('engtech-sidebar-closed'));
    sidebar.addEventListener('click', e=>{
      if(e.target.closest('[data-engtech-logout]')) logout();
    });

    window.addEventListener('resize', ()=>{
      const mob = window.innerWidth <= 860;
      document.body.classList.toggle('engtech-mobile', mob);
      if(mob) document.body.classList.add('engtech-sidebar-closed');
    }, {passive:true});
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
