/*
  Blinders 0.3.6 — Guest Sheet Sync
  Lê a planilha como convidado/somente leitura.
  Não usa Apps Script e não altera a planilha.
*/
const GSS_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const GSS_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const GSS_TOKEN='BLINDERS_TOKEN_V25';
const GSS_MEMBER='BLINDERS_MEMBER_V25';
const GSS_SHEET_ID='1cUVGRl63tyJvxRK-9nlAhnLBdgunEy9OU-sKYNIx83Y';
const GSS_DEFAULT_CSV=`https://docs.google.com/spreadsheets/d/${GSS_SHEET_ID}/gviz/tq?tqx=out:csv&gid=0`;

function gssToken(){return localStorage.getItem(GSS_TOKEN)||''}
function gssMember(){try{return JSON.parse(localStorage.getItem(GSS_MEMBER)||'null')}catch{return null}}
function gssAdmin(){const m=gssMember();return !!m&&['admin','owner'].includes(m.role)}
function gssEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function gssStatus(msg,type=''){const b=document.querySelector('#statusBox');if(b){b.className='status '+type;b.innerHTML=msg}}
async function gssRpc(name,params={}){
  const res=await fetch(`${GSS_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{apikey:GSS_KEY,Authorization:`Bearer ${GSS_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text();let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok)throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}
function gssParseCSV(text){
  const rows=[];let row=[],cur='',q=false;
  for(let i=0;i<text.length;i++){
    const c=text[i],n=text[i+1];
    if(c==='"'&&q&&n==='"'){cur+='"';i++;continue}
    if(c==='"'){q=!q;continue}
    if(c===','&&!q){row.push(cur);cur='';continue}
    if((c==='\n'||c==='\r')&&!q){
      if(c==='\r'&&n==='\n')i++;
      row.push(cur);rows.push(row);row=[];cur='';continue
    }
    cur+=c;
  }
  if(cur.length||row.length){row.push(cur);rows.push(row)}
  return rows.map(r=>r.map(x=>String(x||'').trim()));
}
function gssNumber(v){
  let s=String(v??'').trim();
  if(!s)return 0;
  s=s.replace(/[^\d,.\-]/g,'');
  if(!s||s==='-')return 0;
  if(s.includes(',')&&s.includes('.'))s=s.replace(/\./g,'').replace(',','.');
  else if(s.includes(','))s=s.replace(',','.');
  const n=Number(s);
  return Number.isFinite(n)?n:0;
}
function gssExtractAccounts(rows){
  const out=[], seen=new Set();
  for(let r=0;r<rows.length;r++){
    const row=rows[r].map(x=>String(x||'').trim());
    for(let i=0;i<row.length-1;i++){
      if(row[i].toLowerCase()==='vila' && row[i+1].toUpperCase()==='CONTA'){
        for(let k=r+1;k<rows.length;k++){
          const rr=rows[k]||[];
          const kind=String(rr[i]||'').trim();
          const conta=String(rr[i+1]||'').trim().toUpperCase();
          if(!conta||conta==='CONTA')continue;
          if(!/^[A-Z]{2,}[A-Z0-9]{1,}$/.test(conta))continue;
          if(seen.has(conta))continue;
          seen.add(conta);
          out.push({
            sourceRow:k+1,
            kind:kind||'Conta',
            vila:kind||'',
            conta,
            level:gssNumber(rr[i+2]),
            ryosB:gssNumber(rr[i+3]),
            salarioB:gssNumber(rr[i+4]),
            cargos:String(rr[i+5]||'').trim(),
            fogo:gssNumber(rr[i+6]),
            pedra:gssNumber(rr[i+7]),
            personagem:String(rr[i+8]||'').trim(),
            tesouroB:gssNumber(rr[i+9]),
            raw:rr.slice(i,i+10)
          });
        }
      }
    }
  }
  return out;
}
async function gssFetchCSV(url){
  const res=await fetch(url,{cache:'no-store',mode:'cors'});
  if(!res.ok)throw new Error('Não consegui ler como convidado. A planilha precisa estar em “qualquer pessoa com o link pode ver” ou publicada na web.');
  const text=await res.text();
  if(text.includes('<html')||text.includes('<!DOCTYPE'))throw new Error('O Google retornou HTML em vez de CSV. O link não está público como CSV.');
  return text;
}
async function gssSync(csv,url){
  const rows=gssParseCSV(csv);
  const accounts=gssExtractAccounts(rows);
  if(!accounts.length)throw new Error('Nenhuma conta encontrada no CSV.');
  let imported=0,emshby=null;
  for(let i=0;i<accounts.length;i+=250){
    const part=accounts.slice(i,i+250);
    const data=await gssRpc('app_guest_sheet_sync_push',{p_token:gssToken(),p_source_url:url,p_accounts:part});
    imported+=data.imported||0;
    if(data.emshby)emshby=data.emshby;
  }
  return {ok:true,found:accounts.length,imported,emshby};
}
function gssBoot(){
  if(document.body.dataset.page!=='guest-sheet-sync')return;
  if(!gssAdmin()){location.href='/member/start.html';return}
  const urlInput=document.querySelector('#guestCsvUrl');
  const log=document.querySelector('#guestSyncLog');
  const paste=document.querySelector('#guestCsvPaste');
  urlInput.value=GSS_DEFAULT_CSV;
  function print(v){log.textContent=typeof v==='string'?v:JSON.stringify(v,null,2)}
  document.querySelector('#guestTestBtn').onclick=async()=>{
    try{
      gssStatus('Testando leitura como convidado...');
      const csv=await gssFetchCSV(urlInput.value.trim()||GSS_DEFAULT_CSV);
      const rows=gssParseCSV(csv);
      const accounts=gssExtractAccounts(rows);
      const em=accounts.find(a=>a.conta==='EMSHBY');
      print({ok:true,rows:rows.length,accounts:accounts.length,emshby:em||null});
      gssStatus('Leitura como convidado funcionou.','success');
    }catch(e){print(e.message);gssStatus(gssEsc(e.message),'error')}
  };
  document.querySelector('#guestSyncBtn').onclick=async()=>{
    try{
      gssStatus('Sincronizando como convidado...');
      const url=urlInput.value.trim()||GSS_DEFAULT_CSV;
      const csv=await gssFetchCSV(url);
      const data=await gssSync(csv,url);
      print(data);
      gssStatus('Sincronização concluída.','success');
    }catch(e){print(e.message);gssStatus(gssEsc(e.message),'error')}
  };
  document.querySelector('#guestPasteBtn').onclick=async()=>{
    try{
      gssStatus('Importando CSV colado...');
      const data=await gssSync(paste.value,'guest_manual_paste');
      print(data);
      gssStatus('CSV importado.','success');
    }catch(e){print(e.message);gssStatus(gssEsc(e.message),'error')}
  };
  gssRpc('app_guest_sheet_sync_status',{p_token:gssToken()}).then(print).catch(e=>print(e.message));
}
function gssPatchMenu(){
  if(!gssAdmin())return;
  document.querySelectorAll('.nav,.engtech-nav').forEach(n=>{
    if(!n.querySelector('a[href="/owner/guest-sheet-sync.html"]')){
      n.insertAdjacentHTML('afterbegin','<a class="btn" href="/owner/guest-sheet-sync.html" data-admin-only>Planilha Convidado</a>');
    }
  });
}
document.addEventListener('DOMContentLoaded',()=>{gssPatchMenu();gssBoot()});
