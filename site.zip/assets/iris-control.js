const IRIS38_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const IRIS38_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXAiLCJyZWYiOiJsYm1tcWZnY3lpbWlqYXFudnZweCIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzgwNDE2NTY0LCJleHAiOjIwOTU5OTI1NjR9._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
/* fallback caso a key antiga acima não bata em alguns pacotes */
const IRIS38_KEY_FALLBACK='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJIUzI1NiIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const IRIS38_TOKEN='BLINDERS_TOKEN_V25';
const IRIS38_MEMBER='BLINDERS_MEMBER_V25';
function iris38Key(){return (window.MOD030_KEY||window.ZLS_KEY||window.C37_KEY||IRIS38_KEY_FALLBACK)}
function iris38Token(){return localStorage.getItem(IRIS38_TOKEN)||''}
function iris38Member(){try{return JSON.parse(localStorage.getItem(IRIS38_MEMBER)||'null')}catch{return null}}
function iris38Admin(){const m=iris38Member();return !!m&&['admin','owner'].includes(m.role)}
function iris38Esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function iris38Status(msg,type=''){const b=document.querySelector('#statusBox');if(b){b.className='status '+type;b.innerHTML=msg}}
async function iris38Rpc(name,params={}){
  const key=iris38Key();
  const res=await fetch(`${IRIS38_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text();let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok)throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}
function iris38RequireAdmin(){if(!iris38Admin()){location.href='/member/start.html';return false}return true}
function iris38Menu(){return [
  ['overview','Visão geral','Saldo total, cofre EMSHBY, contas ativas e alertas.','◈'],
  ['accounts','Contas IRIS','Buscar, congelar, descongelar, ajustar e auditar contas.','👤'],
  ['transactions','Transações','TX, astral, origem, destino, tipo, status e metadata.','⇄'],
  ['vault','Cofre EMSHBY','Reserva, prêmio máximo, status e limites do banco.','🏦'],
  ['deposits','Depósitos','Pendentes, confirmados e ligação com logs públicos.','⬆'],
  ['withdraws','Saques','Pendentes, confirmados e códigos de retirada.','⬇'],
  ['reconcile','Conciliação','Comparar IRIS com Zarcovi sincronizado.','≋'],
  ['limits','Limites','Aposta mínima/máxima, prêmio máximo e travas.','⚙'],
  ['audit','Auditoria','Ajustes manuais, bloqueios e ações de admin.','🧾'],
  ['safe','Modo seguro','Travar/destravar operações críticas do IRIS.','🛡']
]}
function iris38RenderShell(){
  if(document.body.dataset.page!=='iris-control')return;
  if(!iris38RequireAdmin())return;
  document.querySelector('#irisMenu').innerHTML=iris38Menu().map(m=>`<button class="iris-control-option" data-tab="${m[0]}"><span class="iris-icon">${m[3]}</span><span><h2>${iris38Esc(m[1])}</h2><p>${iris38Esc(m[2])}</p></span><span class="arrow">›</span></button>`).join('');
  document.addEventListener('click',e=>{const tab=e.target.closest('[data-tab]')?.dataset?.tab;if(tab)iris38LoadTab(tab)});
  iris38LoadTab('overview');
}
async function iris38LoadTab(tab){
  const out=document.querySelector('#irisContent');
  out.innerHTML='<section class="iris-card"><p>Carregando...</p></section>';
  try{
    if(tab==='overview')return iris38Overview(out);
    if(tab==='accounts')return iris38Accounts(out);
    if(tab==='transactions')return iris38Transactions(out);
    if(tab==='vault')return iris38Vault(out);
    if(tab==='deposits')return iris38Deposits(out);
    if(tab==='withdraws')return iris38Withdraws(out);
    if(tab==='reconcile')return iris38Reconcile(out);
    if(tab==='limits')return iris38Limits(out);
    if(tab==='audit')return iris38Audit(out);
    if(tab==='safe')return iris38Safe(out);
  }catch(e){out.innerHTML=`<section class="status error">${iris38Esc(e.message)}</section>`}
}
async function iris38Overview(out){
  const d=await iris38Rpc('app_iris38_overview',{p_token:iris38Token()});const s=d.summary||{};
  out.innerHTML=`<section class="iris-control-grid">${[['Saldo total membros',s.membersBalanceLabel],['Cofre EMSHBY',s.vaultLabel],['Contas ativas',s.activeAccounts],['Contas congeladas',s.frozenAccounts],['TX hoje',s.transactionsToday],['Alertas',s.openAlerts],['Depósitos pendentes',s.pendingDeposits],['Saques pendentes',s.pendingWithdraws]].map(x=>`<article class="card iris-control-kpi"><span>${iris38Esc(x[0])}</span><strong>${iris38Esc(x[1]??0)}</strong></article>`).join('')}</section><section class="iris-card" style="margin-top:14px"><h2>Estado do IRIS</h2><p class="iris-note">${iris38Esc(s.message||'Sistema pronto.')}</p></section>`;
}
async function iris38Accounts(out){
  out.innerHTML=`<section class="iris-card"><h2>Buscar conta</h2><div class="iris-form-grid"><label>Nick, IRIS, Zarcovi ou ID amigo<input id="irisAccountQuery" placeholder="Ex: GE9502"></label><button class="btn" id="irisSearchBtn">Buscar</button></div></section><section class="iris-card" style="margin-top:14px;overflow:auto" id="irisAccountResult">Digite uma busca.</section>`;
  document.querySelector('#irisSearchBtn').onclick=async()=>{
    const q=document.querySelector('#irisAccountQuery').value.trim();
    const d=await iris38Rpc('app_iris38_search_accounts',{p_token:iris38Token(),p_query:q});
    const rows=d.accounts||[];
    document.querySelector('#irisAccountResult').innerHTML=rows.length?`<table class="iris-table"><thead><tr><th>Membro</th><th>Conta</th><th>Saldo</th><th>Status</th><th>Ações</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${iris38Esc(r.nick)}<br><span class="iris-pill">${iris38Esc(r.role)}</span></td><td>${iris38Esc(r.zarcoviAccount)}<br>${iris38Esc(r.irisId)}</td><td>${iris38Esc(r.balanceLabel)}</td><td>${iris38Esc(r.status)} / ${r.frozen?'<span class="iris-bad">congelada</span>':'<span class="iris-good">livre</span>'}</td><td><button class="btn ghost" data-freeze="${r.id}">Congelar</button><button class="btn ghost" data-unfreeze="${r.id}">Descongelar</button><button class="btn" data-adjust="${r.id}">Ajustar</button></td></tr>`).join('')}</tbody></table>`:'<p>Nenhuma conta encontrada.</p>';
  };
}
async function iris38Transactions(out){
  const d=await iris38Rpc('app_iris38_transactions',{p_token:iris38Token(),p_limit:80});
  out.innerHTML=`<section class="iris-card" style="overflow:auto"><h2>Transações recentes</h2><table class="iris-table"><thead><tr><th>Hora</th><th>TX</th><th>Tipo</th><th>Origem</th><th>Destino</th><th>Valor</th><th>Status</th></tr></thead><tbody>${(d.transactions||[]).map(t=>`<tr><td>${iris38Esc(t.createdAt)}</td><td>${iris38Esc(t.txCode)}<br><span class="iris-pill">${iris38Esc(t.astralCode)}</span></td><td>${iris38Esc(t.type)}</td><td>${iris38Esc(t.from)}</td><td>${iris38Esc(t.to)}</td><td>${iris38Esc(t.amountLabel)}</td><td>${iris38Esc(t.status)}</td></tr>`).join('')}</tbody></table></section>`;
}
async function iris38Vault(out){
  const d=await iris38Rpc('app_iris38_vault',{p_token:iris38Token()});const v=d.vault||{};
  out.innerHTML=`<section class="iris-control-grid"><article class="card iris-control-kpi"><span>Cofre</span><strong>${iris38Esc(v.balanceLabel)}</strong></article><article class="card iris-control-kpi"><span>Reserva</span><strong>${iris38Esc(v.reserveLabel)}</strong></article><article class="card iris-control-kpi"><span>Disponível</span><strong>${iris38Esc(v.availableLabel)}</strong></article><article class="card iris-control-kpi"><span>Prêmio máximo</span><strong>${iris38Esc(v.maxPrizeLabel)}</strong></article></section><section class="iris-card" style="margin-top:14px"><h2>Configurar cofre</h2><div class="iris-form-grid"><label>Reserva %<input id="vaultReserve" type="number" min="0" max="90" value="${iris38Esc(v.reservePercent||10)}"></label><label>Prêmio máximo %<input id="vaultPrize" type="number" min="1" max="90" value="${iris38Esc(v.maxPrizePercent||10)}"></label><button class="btn" id="saveVaultBtn">Salvar regras</button></div><div id="vaultStatus" class="status"></div></section>`;
  document.querySelector('#saveVaultBtn').onclick=async()=>{await iris38Rpc('app_iris38_set_vault_rules',{p_token:iris38Token(),p_reserve_percent:Number(document.querySelector('#vaultReserve').value||10),p_max_prize_percent:Number(document.querySelector('#vaultPrize').value||10)});document.querySelector('#vaultStatus').className='status success';document.querySelector('#vaultStatus').textContent='Regras do cofre salvas.'};
}
async function iris38Deposits(out){
  const d=await iris38Rpc('app_iris38_deposits',{p_token:iris38Token()});
  out.innerHTML=`<section class="iris-card" style="overflow:auto"><h2>Depósitos</h2><table class="iris-table"><thead><tr><th>Membro</th><th>Conta</th><th>Valor</th><th>Status</th><th>Data</th></tr></thead><tbody>${(d.deposits||[]).map(x=>`<tr><td>${iris38Esc(x.member)}</td><td>${iris38Esc(x.account)}</td><td>${iris38Esc(x.amountLabel)}</td><td>${iris38Esc(x.status)}</td><td>${iris38Esc(x.createdAt)}</td></tr>`).join('')}</tbody></table></section>`;
}
async function iris38Withdraws(out){
  const d=await iris38Rpc('app_iris38_withdraws',{p_token:iris38Token()});
  out.innerHTML=`<section class="iris-card" style="overflow:auto"><h2>Saques</h2><table class="iris-table"><thead><tr><th>Membro</th><th>Conta</th><th>Valor</th><th>Código</th><th>Status</th><th>Data</th></tr></thead><tbody>${(d.withdraws||[]).map(x=>`<tr><td>${iris38Esc(x.member)}</td><td>${iris38Esc(x.account)}</td><td>${iris38Esc(x.amountLabel)}</td><td>${iris38Esc(x.code)}</td><td>${iris38Esc(x.status)}</td><td>${iris38Esc(x.createdAt)}</td></tr>`).join('')}</tbody></table></section>`;
}
async function iris38Reconcile(out){
  out.innerHTML=`<section class="iris-card"><h2>Conciliação IRIS x Zarcovi</h2><p class="iris-note">Compara contas criadas no app com saldos sincronizados da planilha.</p><button class="btn" id="reconcileBtn">Executar conciliação</button><pre class="status iris-log" id="reconcileResult"></pre></section>`;
  document.querySelector('#reconcileBtn').onclick=async()=>{const d=await iris38Rpc('app_iris38_reconcile_zarcovi',{p_token:iris38Token()});document.querySelector('#reconcileResult').textContent=JSON.stringify(d,null,2)};
}
async function iris38Limits(out){
  const d=await iris38Rpc('app_iris38_limits',{p_token:iris38Token()});
  out.innerHTML=`<section class="iris-card" style="overflow:auto"><h2>Limites dos jogos</h2><p class="iris-note">Padrão atual: mínimo 1500B / 1,5T e máximo 3T.</p><table class="iris-table"><thead><tr><th>Jogo</th><th>Mínimo</th><th>Máximo</th><th>Status</th></tr></thead><tbody>${(d.rules||[]).map(r=>`<tr><td>${iris38Esc(r.gameName)}</td><td>${iris38Esc(r.minLabel)}</td><td>${iris38Esc(r.maxLabel)}</td><td>${r.active?'Ativo':'Inativo'}</td></tr>`).join('')}</tbody></table><button class="btn" id="applyDefaultLimits">Aplicar padrão 1,5T / 3T</button><div id="limitStatus" class="status"></div></section>`;
  document.querySelector('#applyDefaultLimits').onclick=async()=>{await iris38Rpc('app_iris38_apply_default_limits',{p_token:iris38Token()});document.querySelector('#limitStatus').className='status success';document.querySelector('#limitStatus').textContent='Limites padrão aplicados.'};
}
async function iris38Audit(out){
  const d=await iris38Rpc('app_iris38_audit',{p_token:iris38Token()});
  out.innerHTML=`<section class="iris-card" style="overflow:auto"><h2>Auditoria IRIS</h2><table class="iris-table"><thead><tr><th>Hora</th><th>Admin</th><th>Ação</th><th>Mensagem</th></tr></thead><tbody>${(d.rows||[]).map(r=>`<tr><td>${iris38Esc(r.createdAt)}</td><td>${iris38Esc(r.actor)}</td><td>${iris38Esc(r.action)}</td><td>${iris38Esc(r.message)}</td></tr>`).join('')}</tbody></table></section>`;
}
async function iris38Safe(out){
  const d=await iris38Rpc('app_iris38_safe_state',{p_token:iris38Token()});
  out.innerHTML=`<section class="iris-card"><h2>Modo seguro IRIS</h2><p class="iris-note">Quando ativo, pausa operações críticas como apostas e ajustes automáticos.</p><p>Status atual: <strong>${d.safeMode?'Ativo':'Desativado'}</strong></p><button class="btn iris-danger" id="safeOnBtn">Ativar modo seguro</button><button class="btn ghost" id="safeOffBtn">Desativar modo seguro</button><div id="safeStatus" class="status"></div></section>`;
  document.querySelector('#safeOnBtn').onclick=async()=>{await iris38Rpc('app_iris38_toggle_safe',{p_token:iris38Token(),p_enabled:true});document.querySelector('#safeStatus').className='status success';document.querySelector('#safeStatus').textContent='Modo seguro ativado.'};
  document.querySelector('#safeOffBtn').onclick=async()=>{await iris38Rpc('app_iris38_toggle_safe',{p_token:iris38Token(),p_enabled:false});document.querySelector('#safeStatus').className='status success';document.querySelector('#safeStatus').textContent='Modo seguro desativado.'};
}
function iris38PatchMenu(){if(!iris38Admin())return;document.querySelectorAll('.nav,.engtech-nav').forEach(n=>{if(!n.querySelector('a[href="/owner/iris-control.html"]'))n.insertAdjacentHTML('afterbegin','<a class="btn" href="/owner/iris-control.html" data-admin-only>IRIS Control</a>')})}
document.addEventListener('click',async e=>{
  const freeze=e.target?.dataset?.freeze,unfreeze=e.target?.dataset?.unfreeze,adjust=e.target?.dataset?.adjust;
  if(freeze||unfreeze){await iris38Rpc('app_iris38_set_account_freeze',{p_token:iris38Token(),p_member_id:freeze||unfreeze,p_frozen:!!freeze,p_reason:freeze?'Congelado pelo IRIS Control':'Descongelado pelo IRIS Control'});iris38Status(freeze?'Conta congelada.':'Conta descongelada.','success');setTimeout(()=>iris38LoadTab('accounts'),400)}
  if(adjust){const amount=prompt('Valor do ajuste. Ex: 1500B, 1.5T, -500B');if(!amount)return;const reason=prompt('Motivo do ajuste:')||'Ajuste manual IRIS';await iris38Rpc('app_iris38_adjust_balance',{p_token:iris38Token(),p_member_id:adjust,p_amount:amount,p_reason:reason});iris38Status('Ajuste aplicado.','success');setTimeout(()=>iris38LoadTab('accounts'),400)}
});
document.addEventListener('DOMContentLoaded',()=>{iris38PatchMenu();iris38RenderShell()});
