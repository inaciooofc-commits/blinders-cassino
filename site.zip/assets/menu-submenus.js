/*
  Blinders 0.3.8 — Menu hambúrguer com submenus.
  Agrupa links automaticamente para diminuir lotação do sidebar.
*/
(function(){
  const MEMBER=localStorage.getItem('BLINDERS_MEMBER_V25');
  let role='user';
  try{role=JSON.parse(MEMBER||'{}').role||'user'}catch(e){}
  const isAdmin=['admin','owner'].includes(role);

  const groups=[
    {key:'main',title:'Principal',icon:'⌂',items:[
      ['/menu.html','Menu geral'],['/member/start.html','Lobby'],['/member/status.html','Meu status'],['/events/index.html','Eventos'],['/leaderboard/index.html','Ranking']
    ]},
    {key:'iris',title:'Banco IRIS',icon:'◈',items:[
      ['/iris/index.html','Banco IRIS'],['/iris/history.html','Histórico'],['/iris/deposit.html','Depósito'],['/iris/withdraw.html','Saque'],['/iris/transfer.html','Transferir']
    ]},
    {key:'games',title:'Jogos',icon:'🎮',items:[
      ['/play/index.html','Jogos'],['/play/game.html?game=blackjack','Blackjack'],['/play/game.html?game=roleta','Roleta'],['/play/game.html?game=dados','Dados'],['/play/game.html?game=bingo','Bingo'],['/play/game.html?game=slots','Slots']
    ]},
    {key:'community',title:'Comunidade',icon:'💬',items:[
      ['/member/chat.html','Chat'],['/member/friends.html','Amigos'],['/member/clans.html','Clãs'],['/member/inventory.html','Inventário'],['/member/bonus.html','Bônus'],['/member/change-password.html','Senha']
    ]},
    {key:'admin',title:'Admin',icon:'🛡️',admin:true,items:[
      ['/owner/official-dashboard.html','Painel oficial'],['/owner/admin-menu.html','Menu admin'],['/owner/iris-control.html','IRIS Control'],['/owner/create-account.html','Criar contas'],['/owner/delete-accounts.html','Excluir contas'],['/owner/bonus-codes.html','Bônus'],['/owner/vault.html','Cofre EMSHBY']
    ]},
    {key:'system',title:'Sistema',icon:'⚙️',admin:true,items:[
      ['/owner/consolidated-sync.html','Sync App'],['/owner/transfer-log.html','Transferências'],['/owner/guest-sheet-sync.html','Planilha'],['/owner/zarcovi-sync.html','Zarcovi'],['/owner/supabase-control.html','Supabase'],['/owner/backups.html','Backups'],['/owner/health.html','Saúde'],['/owner/reports-center.html','Relatórios'],['/owner/audit.html','Auditoria'],['/owner/system-control.html','Lock/Manutenção'],['/owner/sangria.html','Sangria']
    ]}
  ];

  function exists(url){
    return true;
  }
  function currentMatch(url){
    const here=location.pathname+location.search;
    if(url.includes('?'))return here===url;
    return location.pathname===url;
  }
  function build(){
    const navs=[...document.querySelectorAll('.engtech-nav,.nav,aside nav')].filter(n=>!n.dataset.submenuDone);
    navs.forEach(nav=>{
      const oldLinks=[...nav.querySelectorAll('a')];
      if(oldLinks.length<7 && !isAdmin)return;
      const available=new Set(oldLinks.map(a=>a.getAttribute('href')).filter(Boolean));
      nav.dataset.submenuDone='1';
      nav.classList.add('blinders-menu-submenus');
      nav.innerHTML='<div class="blinders-menu-compact-note">Menu organizado por categoria</div>';

      groups.filter(g=>!g.admin||isAdmin).forEach((g,idx)=>{
        const group=document.createElement('section');
        group.className='blinders-menu-group';
        const hasCurrent=g.items.some(i=>currentMatch(i[0]));
        if(hasCurrent || idx===0) group.classList.add('open');
        group.innerHTML=`<button class="blinders-menu-group-btn" type="button"><span><b>${g.icon}</b>${g.title}</span><span class="chev">›</span></button><div class="blinders-menu-group-links"></div>`;
        const links=group.querySelector('.blinders-menu-group-links');
        g.items.forEach(([href,label])=>{
          if(!exists(href))return;
          const a=document.createElement('a');
          a.className='btn ghost';
          a.href=href;
          a.textContent=label;
          if(g.admin)a.setAttribute('data-admin-only','');
          if(currentMatch(href))a.setAttribute('aria-current','page');
          links.appendChild(a);
        });
        if(links.children.length)nav.appendChild(group);
      });

      nav.addEventListener('click',e=>{
        const btn=e.target.closest('.blinders-menu-group-btn');
        if(!btn)return;
        const group=btn.closest('.blinders-menu-group');
        group.classList.toggle('open');
      });
    });
  }
  document.addEventListener('DOMContentLoaded',()=>{setTimeout(build,150);setTimeout(build,800);setTimeout(build,1600)});
})();
