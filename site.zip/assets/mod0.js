const MOD0_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const MOD0_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const MOD0_TOKEN='BLINDERS_TOKEN_V25';
const MOD0_MEMBER='BLINDERS_MEMBER_V25';
const MOD0_WA='5511951289502';

function m0Token(){return localStorage.getItem(MOD0_TOKEN)}
function m0Member(){try{return JSON.parse(localStorage.getItem(MOD0_MEMBER)||'null')}catch{return null}}
function m0Esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function m0Status(msg,type=''){
  const b=document.querySelector('#statusBox');
  if(b){b.className='status '+type;b.innerHTML=msg}
}
function m0Require(admin=false){
  const m=m0Member();
  if(!m||!m0Token()){location.href=admin?'/owner/login.html':'/member/login.html';return null}
  if(admin&&!['admin','owner'].includes(m.role)){location.href='/member/start.html';return null}
  return m;
}
async function m0Rpc(name, params={}){
  const res=await fetch(`${MOD0_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{apikey:MOD0_KEY,Authorization:`Bearer ${MOD0_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text();
  let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok) throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}
function m0WaUrl(message){
  return `https://wa.me/${MOD0_WA}?text=${encodeURIComponent(message)}`;
}
function m0AttachEverywhere(){
  document.querySelectorAll('form').forEach(f=>{
    f.setAttribute('autocomplete','off');
  });
}
function m0SoloStage(game){
  const map={
    roleta:`<div class="mod0-stage-roleta"><div class="wheel"></div></div>`,
    roulette:`<div class="mod0-stage-roleta"><div class="wheel"></div></div>`,
    blackjack:`<div class="mod0-stage-blackjack"><div class="cards"><div class="cardx">A♠</div><div class="cardx">10♥</div><div class="cardx">K♣</div></div></div>`,
    dados:`<div class="mod0-stage-dados"><div class="dices"><div class="dicex">⚄</div><div class="dicex">⚂</div></div></div>`,
    bingo:`<div class="mod0-stage-bingo"><div class="balls"><div class="ball">B7</div><div class="ball">I16</div><div class="ball">N34</div><div class="ball">G49</div><div class="ball">O71</div></div></div>`,
    slots:`<div class="mod0-stage-slots"><div class="reels"><div class="reelx">7</div><div class="reelx">★</div><div class="reelx">B</div></div></div>`,
    crash:`<div class="mod0-stage-crash"><div class="rocket">🚀</div></div>`,
    memoria:`<div class="mod0-stage-memoria"><div class="cards"><div class="cardx">?</div><div class="cardx">★</div><div class="cardx">?</div><div class="cardx">★</div></div></div>`,
    mines:`<div class="mod0-stage-mines"><div class="gridmines"><div class="cell safe">♦</div><div class="cell mine">✖</div><div class="cell safe">♠</div><div class="cell safe">♥</div><div class="cell safe">♣</div><div class="cell safe">♦</div><div class="cell mine">✖</div><div class="cell safe">♠</div></div></div>`,
    plinko:`<div class="mod0-stage-plinko"><div class="pins">${Array.from({length:21}).map((_,i)=>`<div class="${i===10?'chip':'pin'}"></div>`).join('')}</div></div>`,
    coinflip:`<div class="mod0-stage-coinflip"><div class="coin">🪙</div></div>`,
    baccarat:`<div class="mod0-stage-baccarat"><div class="cards"><div class="cardx">9♦</div><div class="cardx">2♣</div><div class="cardx">8♠</div><div class="cardx">A♥</div></div></div>`
  };
  return map[game] || `<div class="mod0-stage-slots"><div class="reels"><div class="reelx">B</div><div class="reelx">★</div><div class="reelx">7</div></div></div>`;
}
function m0BootBetPage(){
  if(document.body.dataset.page!=='bet') return;
  const game=(new URLSearchParams(location.search).get('game')||'roleta').toLowerCase();
  const form=document.querySelector('#betForm');
  if(!form) return;
  const wrap=document.createElement('main');
  wrap.className='app';
  wrap.innerHTML=`<div class="top"><div><h1 id="gameHeroTitle">${m0Esc(game.toUpperCase())}</h1><p>Jogo individual com aposta debitada da conta IRIS do jogador.</p></div><a class="btn ghost" href="/play/index.html">Voltar</a></div>
  <section class="mod0-solo-layout">
    <article class="card mod0-solo-stage" id="soloGameStage">${m0SoloStage(game)}</article>
    <section></section>
  </section>`;
  const right=wrap.querySelector('section section');
  form.classList.add('box');
  right.appendChild(form);
  form.insertAdjacentHTML('beforeend', `<p class="mod0-help">Se ganhar, recebe 2x a aposta. Se perder, o valor fica no banco.</p>`);
  document.body.innerHTML='';
  document.body.appendChild(wrap);
  form.addEventListener('submit', ()=>{
    const st=document.querySelector('#soloGameStage');
    if(st) st.style.transform='scale(1.02)';
    setTimeout(()=>{ if(st) st.style.transform=''; },700);
  }, {capture:true});
}
function m0BuildWaButtonsFromStatus(){
  const p=location.pathname;
  const s=document.querySelector('#statusBox');
  if(!s) return;
  const render=()=>{
    const txt=s.innerText||'';
    let html=s.innerHTML;
    if(txt.includes('Código:') && !s.querySelector('.m0wa')){
      let code=(txt.match(/Código:\s*([A-Z0-9\-]+)/i)||[])[1]||'';
      let iris=(txt.match(/ID IRIS:\s*([A-Z0-9\-]+)/i)||[])[1]||'';
      let tx=(txt.match(/TX:\s*([A-Z0-9\-]+)/i)||[])[1]||'';
      let astral=(txt.match(/Astral:\s*([A-Z0-9\-]+)/i)||[])[1]||'';
      let msg='Blinders Cassino';
      if(p.includes('/member/register')){
        msg=`Olá admin, solicito confirmação de conta no Blinders Cassino.%0ACódigo: ${code}%0AID IRIS: ${iris}`;
      }else if(p.includes('/iris/withdraw')){
        msg=`Olá admin, solicito confirmação de saque.%0ACódigo: ${code}%0ATX: ${tx}%0AAstral: ${astral}`;
      }else if(p.includes('/iris/deposit')){
        msg=`Olá admin, solicito análise de depósito.%0ATX: ${tx}%0AAstral: ${astral}`;
      }
      html += `<div class="actions" style="margin-top:10px"><a class="btn m0wa" target="_blank" rel="noopener" href="https://wa.me/${MOD0_WA}?text=${msg}">Enviar código ao admin no WhatsApp</a></div>`;
      s.innerHTML=html;
    }
  };
  const obs=new MutationObserver(render);
  obs.observe(s,{childList:true,subtree:true,characterData:true});
  setTimeout(render,250);
}
function m0BootAdminCenter(){
  if(document.body.dataset.page!=='mod0-admin-center') return;
  m0Require(true);
  m0Rpc('app_mod0_admin_center',{p_token:m0Token()}).then(data=>{
    const s=data.summary||{};
    document.querySelector('#adminSummary').innerHTML=[
      ['Contas pendentes',s.pendingAccounts||0,'/owner/confirm-accounts-code.html'],
      ['Depósitos pendentes',s.pendingDeposits||0,'/owner/confirm-deposits-code.html'],
      ['Saques pendentes',s.pendingWithdraws||0,'/owner/confirm-withdraws-code.html'],
      ['Transferências',s.recentTransfers||0,'/owner/confirm-transfers-code.html'],
      ['Clãs',s.clans||0,'/clans/index.html']
    ].map(x=>`<a class="card admin-menu-card" href="${x[2]}"><h2>${x[0]}</h2><div class="kpi">${x[1]}</div><p>Abrir menu</p></a>`).join('');
  }).catch(e=>m0Status(m0Esc(e.message),'error'));
}
function m0RenderCodeList(listEl, rows, kind){
  listEl.innerHTML=(rows||[]).map(r=>{
    const waMsg = r.whatsappMessage || `${r.title||kind} | código ${r.code||r.txCode||''}`;
    const codeShow = r.code||r.txCode||r.withdrawCode||'';
    return `<article class="card mod0-confirm-card">
      <h2>${m0Esc(r.title||kind)}</h2>
      ${r.body?`<p>${m0Esc(r.body)}</p>`:''}
      ${r.nick?`<div class="row"><span>Nick</span><b>${m0Esc(r.nick)}</b></div>`:''}
      ${r.zarcovi?`<div class="row"><span>Conta Zarcovi</span><b>${m0Esc(r.zarcovi)}</b></div>`:''}
      ${r.irisId?`<div class="row"><span>ID IRIS</span><b>${m0Esc(r.irisId)}</b></div>`:''}
      ${r.amountLabel?`<div class="row"><span>Valor</span><b>${m0Esc(r.amountLabel)}</b></div>`:''}
      ${r.payerAccount?`<div class="row"><span>Conta</span><b>${m0Esc(r.payerAccount)}</b></div>`:''}
      ${r.targetAccount?`<div class="row"><span>Destino</span><b>${m0Esc(r.targetAccount)}</b></div>`:''}
      ${r.txCode?`<div class="row"><span>TX</span><b class="mod0-code">${m0Esc(r.txCode)}</b></div>`:''}
      ${r.astralCode?`<div class="row"><span>Astral</span><b class="mod0-code">${m0Esc(r.astralCode)}</b></div>`:''}
      ${codeShow?`<div class="row"><span>Código</span><b class="mod0-code">${m0Esc(codeShow)}</b></div>`:''}
      <div class="actions">
        <input data-code-input="${kind}" value="${m0Esc(codeShow)}" placeholder="Digite o código">
        <button class="btn" data-confirm-kind="${kind}" data-code="${m0Esc(codeShow)}">Confirmar</button>
        <a class="btn ghost mod0-whats" target="_blank" rel="noopener" href="${m0WaUrl(waMsg)}">WhatsApp admin</a>
      </div>
    </article>`;
  }).join('') || '<article class="card"><h2>Nada pendente</h2></article>';
}
function m0BootConfirmPage(pageKind){
  const map = {
    'mod0-accounts': ['app_mod0_admin_pending_accounts','app_mod0_admin_confirm_account'],
    'mod0-deposits': ['app_mod0_admin_pending_deposits','app_mod0_admin_confirm_deposit_by_code'],
    'mod0-withdraws': ['app_mod0_admin_pending_withdraws','app_mod0_admin_confirm_withdraw_by_code'],
    'mod0-transfers': ['app_mod0_admin_recent_transfers','app_mod0_admin_confirm_transfer_by_code']
  };
  if(document.body.dataset.page!==pageKind) return;
  m0Require(true);
  const [listFn, confirmFn] = map[pageKind];
  const listEl=document.querySelector('#codeList');
  const kind = pageKind.replace('mod0-','').replace(/s$/,'');
  async function load(){
    try{
      const data=await m0Rpc(listFn,{p_token:m0Token()});
      m0RenderCodeList(listEl,data.items||data.transfers||[], kind);
    }catch(e){m0Status(m0Esc(e.message),'error')}
  }
  document.addEventListener('click', async e=>{
    const btn=e.target.closest('[data-confirm-kind]');
    if(!btn) return;
    const wrap=btn.closest('.mod0-confirm-card');
    const input=wrap?.querySelector('[data-code-input]')?.value?.trim() || btn.dataset.code || '';
    try{
      m0Status('Confirmando...');
      await m0Rpc(confirmFn,{p_token:m0Token(),p_code:input});
      m0Status('Confirmado com sucesso.','success');
      load();
    }catch(err){m0Status(m0Esc(err.message),'error')}
  });
  load();
}
function m0BootHomeVisual(){
  if(location.pathname !== '/member/start.html') return;
  const app=document.querySelector('main.app');
  if(!app || app.querySelector('.mod0-hero')) return;
  const hero=document.createElement('section');
  hero.className='mod0-hero';
  hero.innerHTML=`
    <article class="mod0-banner">
      <h1>Seu cassino sempre com você</h1>
      <p>Ambiente premium, apostas organizadas, Banco IRIS, mesas com mestre, clãs e experiência visual mais polida.</p>
      <div class="mod0-cta">
        <a class="btn" href="/play/index.html">Jogar agora</a>
        <a class="btn ghost" href="/iris/index.html">Banco IRIS</a>
        <a class="btn ghost" href="/shop/index.html">Loja</a>
      </div>
    </article>
    <div class="mod0-side">
      <article class="card mod0-mini-panel"><h2>IRIS</h2><p>Transferências, depósitos e saques com TX e código astral.</p></article>
      <article class="card mod0-mini-panel"><h2>EGNTech Engine</h2><p>Animações, mesas e jogo individual com visual mais limpo.</p></article>
    </div>`;
  app.insertBefore(hero, app.children[1] || null);
}
document.addEventListener('DOMContentLoaded',()=>{
  m0AttachEverywhere();
  m0BootBetPage();
  m0BootHomeVisual();
  m0BootAdminCenter();
  m0BootConfirmPage('mod0-accounts');
  m0BootConfirmPage('mod0-deposits');
  m0BootConfirmPage('mod0-withdraws');
  m0BootConfirmPage('mod0-transfers');
  m0BuildWaButtonsFromStatus();
});
