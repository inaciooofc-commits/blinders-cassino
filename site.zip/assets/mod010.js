/*
  Blinders Cassino — Módulo 0.1.0
  - Membros comuns não veem botões admin
  - Admin cria contas
  - admin@usuario cria admin, login usa usuario
  - Admin menu em lista com descrição
*/
const MOD010_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const MOD010_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const MOD010_TOKEN='BLINDERS_TOKEN_V25';
const MOD010_MEMBER='BLINDERS_MEMBER_V25';

function mod010Token(){return localStorage.getItem(MOD010_TOKEN)}
function mod010Member(){try{return JSON.parse(localStorage.getItem(MOD010_MEMBER)||'null')}catch{return null}}
function mod010IsAdmin(){const m=mod010Member();return !!m && ['admin','owner'].includes(m.role)}
function mod010Esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function mod010Status(msg,type=''){const b=document.querySelector('#statusBox');if(b){b.className='status '+type;b.innerHTML=msg}}
async function mod010Rpc(name,params={}){
  const res=await fetch(`${MOD010_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{apikey:MOD010_KEY,Authorization:`Bearer ${MOD010_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text();
  let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok) throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}

function mod010ApplyRoleGuards(){
  const isAdmin=mod010IsAdmin();
  document.body.classList.toggle('mod010-admin',isAdmin);
  document.body.classList.toggle('mod010-member',!isAdmin);

  if(!isAdmin){
    document.querySelectorAll('a[href^="/owner/"], [data-admin-only], .admin-only').forEach(el=>el.remove());
  }

  if(location.pathname.startsWith('/owner/') && !isAdmin && !location.pathname.includes('/owner/login')){
    location.href='/member/start.html';
  }
}

function mod010AdminMenuItems(){
  return [
    {href:'/owner/iris-control.html',icon:'/assets/ui/icons/iris.svg',title:'IRIS Control Center',desc:'Gerenciar contas, saldos, cofre, transações, auditoria e modo seguro do Banco IRIS.'},

    {href:'/menu.html',icon:'/assets/ui/icons/status.svg',title:'Menu geral consolidado',desc:'Todas as áreas do site em lista com descrição.'},
    {href:'/owner/consolidated-sync.html',icon:'/assets/ui/icons/history.svg',title:'Sync seletivo do app',desc:'Sincronizar apenas contas criadas no app e EMSHBY.'},
    {href:'/owner/transfer-log.html',icon:'/assets/ui/icons/iris.svg',title:'Checar transferências',desc:'Ler log público e autorizar depósitos para EMSHBY.'},

    {href:'/owner/guest-sheet-sync.html',icon:'/assets/ui/icons/history.svg',title:'Planilha Convidado',desc:'Ler a planilha como convidado, sem Apps Script e sem alterar nada.'},

    {href:'/owner/apps-script-sync.html',icon:'/assets/ui/icons/settings.svg',title:'Apps Script Sync',desc:'Sincronização estável da planilha Zarcovi direto pelo Google.'},

    {href:'/owner/zarcovi-sync.html',icon:'/assets/ui/icons/history.svg',title:'Zarcovi Sync',desc:'Sincronizar saldos Zarcovi e EMSHBY da planilha.'},

    {href:'/owner/zarcovi-import.html',icon:'/assets/ui/icons/history.svg',title:'Importar Zarcovi',desc:'Conferir e organizar dados extraídos da planilha do banco Zarcovi.'},

    {href:'/owner/supabase-control.html',icon:'/assets/ui/icons/settings.svg',title:'Controle Supabase',desc:'Diagnóstico e reparos seguros das tabelas, funções, rotas e módulos.'},

    {href:'/owner/official-dashboard.html',icon:'/assets/ui/icons/status.svg',title:'Painel oficial',desc:'Resumo estável do sistema, cofre, relatórios e modo seguro.'},
    {href:'/owner/backups.html',icon:'/assets/ui/icons/settings.svg',title:'Backups',desc:'Crie backup lógico e ative/desative o modo seguro.'},
    {href:'/owner/health.html',icon:'/assets/ui/icons/status.svg',title:'Saúde do sistema',desc:'Verifique tabelas, funções e integridade do Supabase.'},
    {href:'/owner/reports-center.html',icon:'/assets/ui/icons/history.svg',title:'Relatórios',desc:'Relatórios diários, banco, jogos, bônus e WhatsApp.'},
    {href:'/owner/audit.html',icon:'/assets/ui/icons/logs.svg',title:'Auditoria',desc:'Ações recentes dos admins e eventos importantes.'},

    {href:'/owner/bonus-codes.html',icon:'/assets/iconpack/gold-chip.svg',title:'Códigos de bônus',desc:'Crie códigos com dinheiro, itens da loja ou os dois.'},
    {href:'/owner/delete-accounts.html',icon:'/assets/ui/icons/report.svg',title:'Excluir contas',desc:'Remova contas inválidas ou problemáticas do sistema.'},
    {href:'/owner/vault.html',icon:'/assets/ui/icons/iris.svg',title:'Cofre EMSHBY',desc:'Configure saldo do cofre e limite pagamentos acima do disponível.'},


    {
      href:'/owner/system-control.html',
      icon:'/assets/ui/icons/settings.svg',
      title:'Lock e Manutenção',
      desc:'Ative lock, manutenção com mensagem e desative tudo instantaneamente.'
    },
    {
      href:'/owner/sangria.html',
      icon:'/assets/ui/icons/iris.svg',
      title:'Sangria',
      desc:'Resumo diário de depósitos, ganhos das mesas, jogos individuais e contas criadas hoje.'
    },

    {
      href:'/owner/create-account.html',
      icon:'/assets/ui/icons/admin.svg',
      title:'Criar conta',
      desc:'Crie membros comuns ou admins. Use admin@nome para criar admin; o login será apenas nome.'
    },
    {
      href:'/owner/confirm-accounts-code.html',
      icon:'/assets/ui/icons/status.svg',
      title:'Confirmar contas',
      desc:'Confirme contas pendentes digitando o código recebido.'
    },
    {
      href:'/owner/confirm-deposits-code.html',
      icon:'/assets/ui/icons/deposit.svg',
      title:'Confirmar depósitos',
      desc:'Confirme depósitos pelo TX após verificar o comprovante.'
    },
    {
      href:'/owner/confirm-withdraws-code.html',
      icon:'/assets/ui/icons/withdraw.svg',
      title:'Confirmar saques',
      desc:'Confirme saques pelo código de retirada enviado ao WhatsApp admin.'
    },
    {
      href:'/owner/confirm-transfers-code.html',
      icon:'/assets/ui/icons/transfer.svg',
      title:'Conferir transferências',
      desc:'Consulte e marque transferências usando o código TX.'
    },
    {
      href:'/owner/notifications.html',
      icon:'/assets/ui/icons/bell.svg',
      title:'Notificações',
      desc:'Veja avisos de banco, reportes e eventos importantes.'
    },
    {
      href:'/owner/transactions.html',
      icon:'/assets/ui/icons/history.svg',
      title:'Transações',
      desc:'Histórico administrativo de transações IRIS.'
    },
    {
      href:'/owner/media.html',
      icon:'/assets/ui/icons/settings.svg',
      title:'Mídia e aparência',
      desc:'Troque rádio, trilha sonora, fundo e identidade visual.'
    },
    {
      href:'/owner/iconpack.html',
      icon:'/assets/ui/icons/shop.svg',
      title:'IconPack',
      desc:'Aplique pacotes de ícones e identidade visual do site.'
    },
    {
      href:'/owner/shop-limit.html',
      icon:'/assets/ui/icons/shop.svg',
      title:'Loja',
      desc:'Controle quantos itens ficam disponíveis na loja.'
    },
    {
      href:'/owner/system-status.html',
      icon:'/assets/ui/icons/status.svg',
      title:'Status do sistema',
      desc:'Resumo técnico, banco, logs e integridade.'
    },
    {
      href:'/owner/reports.html',
      icon:'/assets/ui/icons/report.svg',
      title:'Reportes de usuários',
      desc:'Problemas enviados pelos membros comuns.'
    }
  ];
}

function mod010BootAdminMenu(){
  if(document.body.dataset.page!=='mod010-admin-menu') return;
  if(!mod010IsAdmin()){
    location.href='/member/start.html';
    return;
  }
  const list=document.querySelector('#adminMenuList');
  list.innerHTML=mod010AdminMenuItems().map(item=>`
    <a class="mod010-admin-option" href="${item.href}" data-admin-only>
      <img src="${item.icon}" alt="">
      <span>
        <h2>${mod010Esc(item.title)}</h2>
        <p>${mod010Esc(item.desc)}</p>
      </span>
      <span class="mod010-arrow">›</span>
    </a>
  `).join('');
}

function mod010PreviewRole(){
  const input=document.querySelector('#adminCreateLogin');
  const preview=document.querySelector('#rolePreview');
  if(!input||!preview) return;
  const update=()=>{
    const raw=input.value.trim();
    const isAdmin=raw.toLowerCase().startsWith('admin@');
    const clean=isAdmin?raw.slice(6):raw;
    preview.textContent=isAdmin
      ? `Será criado ADMIN — login: ${clean || 'nome'}`
      : `Será criado MEMBRO comum — login: ${clean || 'nome'}`;
  };
  input.addEventListener('input',update);
  update();
}

function mod010BootCreateAccount(){
  if(document.body.dataset.page!=='mod010-create-account') return;
  if(!mod010IsAdmin()){
    location.href='/member/start.html';
    return;
  }

  mod010PreviewRole();

  const form=document.querySelector('#adminCreateAccountForm');
  form?.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(form);
    try{
      mod010Status('Criando conta...');
      const data=await mod010Rpc('app_mod010_admin_create_member',{
        p_token:mod010Token(),
        p_login_name:String(fd.get('loginName')||'').trim(),
        p_nick:String(fd.get('nick')||'').trim(),
        p_password:String(fd.get('password')||'')
      });

      const role=data.role==='admin'?'ADMIN':'MEMBRO';
      mod010Status(
        `Conta criada com sucesso.\nTipo: ${role}\nLogin: ${mod010Esc(data.loginName)}\nNick: ${mod010Esc(data.nick)}\nID IRIS: ${mod010Esc(data.irisMemberId)}\nStatus: ativa`,
        'success'
      );
      form.reset();
      mod010PreviewRole();
    }catch(err){
      mod010Status(mod010Esc(err.message),'error');
    }
  });
}

function mod010PatchExistingAdminLinks(){
  if(!mod010IsAdmin()) return;
  const panelNav=document.querySelector('body[data-page="panel"] .nav');
  if(panelNav && !panelNav.querySelector('a[href="/owner/admin-menu.html"]')){
    panelNav.insertAdjacentHTML('afterbegin','<a class="btn" href="/owner/admin-menu.html" data-admin-only>Menu ADM</a><a class="btn" href="/owner/create-account.html" data-admin-only>Criar conta</a>');
  }
}

document.addEventListener('DOMContentLoaded',()=>{
  mod010ApplyRoleGuards();
  mod010PatchExistingAdminLinks();
  mod010BootAdminMenu();
  mod010BootCreateAccount();

  setTimeout(mod010ApplyRoleGuards,250);
  setTimeout(mod010ApplyRoleGuards,900);
});
