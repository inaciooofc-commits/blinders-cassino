/*
  Blinders Cassino — Módulo 0.2.0
  Chat, amigos, EMSHBY, sangria, lock/manutenção e renderização
*/
const MOD020_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const MOD020_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const MOD020_TOKEN='BLINDERS_TOKEN_V25';
const MOD020_MEMBER='BLINDERS_MEMBER_V25';
const MOD020_WA='5511951289502';

function m020Token(){return localStorage.getItem(MOD020_TOKEN)}
function m020Member(){try{return JSON.parse(localStorage.getItem(MOD020_MEMBER)||'null')}catch{return null}}
function m020IsAdmin(){const m=m020Member(); return !!m && ['admin','owner'].includes(m.role)}
function m020Esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function m020Status(msg,type=''){const b=document.querySelector('#statusBox'); if(b){b.className='status '+type;b.innerHTML=msg}}
function m020Wa(msg){return `https://wa.me/${MOD020_WA}?text=${encodeURIComponent(msg)}`}

async function m020Rpc(name,params={}){
  const res=await fetch(`${MOD020_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{apikey:MOD020_KEY,Authorization:`Bearer ${MOD020_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text();
  let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok) throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}

function m020Require(admin=false){
  const m=m020Member();
  if(!m||!m020Token()){location.href=admin?'/owner/login.html':'/member/login.html';return null}
  if(admin&&!['admin','owner'].includes(m.role)){location.href='/member/start.html';return null}
  return m;
}

async function m020CheckAccessOnLoginPage(){
  if(!location.pathname.includes('/member/login') && !location.pathname.includes('/owner/login')) return;
  try{
    const data=await m020Rpc('app_mod020_public_access_state',{});
    const s=data.state||{};
    const isOwnerLogin=location.pathname.includes('/owner/login');
    if((s.lockEnabled || s.maintenanceEnabled) && !isOwnerLogin){
      const box=document.querySelector('#statusBox') || document.querySelector('.box');
      const msg=s.maintenanceEnabled
        ? (s.maintenanceMessage||'Site em manutenção.')
        : 'Lock ativo. Apenas admins podem entrar.';
      if(box){
        box.insertAdjacentHTML('afterbegin',`<div class="status error"><strong>Entrada bloqueada</strong><br>${m020Esc(msg)}</div>`);
      }
      const forms=document.querySelectorAll('form');
      forms.forEach(f=>{
        f.querySelectorAll('input,button,select,textarea').forEach(i=>i.disabled=true);
      });
    }
  }catch(e){}
}

function m020PatchLoginSubmit(){
  if(!location.pathname.includes('/member/login')) return;
  const form=document.querySelector('form');
  if(!form || form.dataset.m020Patched) return;
  form.dataset.m020Patched='1';
  form.addEventListener('submit',async e=>{
    try{
      const data=await m020Rpc('app_mod020_public_access_state',{});
      const s=data.state||{};
      if(s.lockEnabled || s.maintenanceEnabled){
        e.preventDefault();
        m020Status(s.maintenanceEnabled ? (s.maintenanceMessage||'Site em manutenção.') : 'Lock ativo. Apenas admins podem entrar.','error');
      }
    }catch(err){}
  }, true);
}

function m020PatchGameRender(){
  if(document.body.dataset.page!=='bet') return;
  const form=document.querySelector('#betForm');
  const stage=document.querySelector('#soloGameStage');
  const status=document.querySelector('#statusBox');
  if(!form || !stage || form.dataset.m020Render) return;
  form.dataset.m020Render='1';
  form.addEventListener('submit', e=>{
    stage.innerHTML=`<div class="mod020-render"><div><div class="mod020-render-word">Renderizando...</div><div class="mod020-loader"></div></div></div>`;
    if(status) status.innerHTML='Processando animação e calculando resultado...';
  }, true);
}

function m020BootChat(){
  if(document.body.dataset.page!=='mod020-chat') return;
  const m=m020Require(false); if(!m)return;
  const chatBox=document.querySelector('#chatBox');
  const friendList=document.querySelector('#friendList');
  const form=document.querySelector('#chatForm');
  const friendForm=document.querySelector('#friendForm');
  document.querySelector('#myFriendId').textContent=m.friendId || m.irisMemberId || 'Carregando...';

  async function profile(){
    try{
      const data=await m020Rpc('app_mod020_profile',{p_token:m020Token()});
      document.querySelector('#myFriendId').textContent=data.profile.friendCode;
    }catch(e){}
  }
  async function loadMessages(){
    try{
      const data=await m020Rpc('app_mod020_chat_messages',{p_token:m020Token(),p_limit:60});
      const myId=data.myMemberId;
      chatBox.innerHTML=(data.messages||[]).map(x=>`<div class="mod020-msg ${x.memberId===myId?'me':''}">
        <strong>${m020Esc(x.nick)}</strong>
        <span>${m020Esc(x.body)}</span>
        <small>${m020Esc(x.createdAt)}</small>
      </div>`).join('');
      chatBox.scrollTop=chatBox.scrollHeight;
    }catch(e){chatBox.innerHTML=`<div class="status error">${m020Esc(e.message)}</div>`}
  }
  async function loadFriends(){
    try{
      const data=await m020Rpc('app_mod020_friends',{p_token:m020Token()});
      friendList.innerHTML=(data.friends||[]).map(f=>`<article class="card mod020-friend-card">
        <div class="mod020-avatar">${m020Esc((f.nick||'?').slice(0,1).toUpperCase())}</div>
        <span><strong>${m020Esc(f.nick)}</strong><br><small>${m020Esc(f.friendCode)}</small></span>
        <span class="badge">${m020Esc(f.status)}</span>
      </article>`).join('') || '<article class="card"><h2>Sem amigos</h2><p>Adicione por ID único.</p></article>';
    }catch(e){}
  }
  form?.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(form);
    const body=String(fd.get('body')||'').trim();
    if(!body)return;
    try{
      await m020Rpc('app_mod020_send_chat',{p_token:m020Token(),p_body:body});
      form.reset();
      loadMessages();
    }catch(err){m020Status(m020Esc(err.message),'error')}
  });
  friendForm?.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(friendForm);
    try{
      await m020Rpc('app_mod020_add_friend',{p_token:m020Token(),p_friend_code:String(fd.get('friendCode')||'')});
      m020Status('Amigo adicionado.','success');
      friendForm.reset();
      loadFriends();
    }catch(err){m020Status(m020Esc(err.message),'error')}
  });
  profile(); loadMessages(); loadFriends();
  setInterval(loadMessages,6000);
}

function m020BootAdminSystem(){
  if(document.body.dataset.page!=='mod020-admin-system') return;
  m020Require(true);
  const lockBtn=document.querySelector('#lockBtn');
  const unlockBtn=document.querySelector('#unlockBtn');
  const maintForm=document.querySelector('#maintForm');
  const offMaint=document.querySelector('#offMaint');
  const stateBox=document.querySelector('#stateBox');

  async function load(){
    try{
      const data=await m020Rpc('app_mod020_admin_system_state',{p_token:m020Token()});
      const s=data.state||{};
      stateBox.innerHTML=`<article class="card"><h2>Estado atual</h2>
        <p>Lock: <b>${s.lockEnabled?'ATIVO':'desativado'}</b></p>
        <p>Manutenção: <b>${s.maintenanceEnabled?'ATIVA':'desativada'}</b></p>
        <p>Mensagem: ${m020Esc(s.maintenanceMessage||'-')}</p>
      </article>`;
    }catch(e){m020Status(m020Esc(e.message),'error')}
  }
  lockBtn?.addEventListener('click',async()=>{await m020Rpc('app_mod020_admin_set_lock',{p_token:m020Token(),p_enabled:true});m020Status('Lock ativado.','success');load()});
  unlockBtn?.addEventListener('click',async()=>{await m020Rpc('app_mod020_admin_set_lock',{p_token:m020Token(),p_enabled:false});m020Status('Lock desativado instantaneamente.','success');load()});
  offMaint?.addEventListener('click',async()=>{await m020Rpc('app_mod020_admin_set_maintenance',{p_token:m020Token(),p_enabled:false,p_message:''});m020Status('Manutenção desativada instantaneamente.','success');load()});
  maintForm?.addEventListener('submit',async e=>{
    e.preventDefault();
    const msg=String(new FormData(maintForm).get('message')||'');
    await m020Rpc('app_mod020_admin_set_maintenance',{p_token:m020Token(),p_enabled:true,p_message:msg});
    m020Status('Manutenção ativada.','success');load();
  });
  load();
}

function m020BootSangria(){
  if(document.body.dataset.page!=='mod020-sangria') return;
  m020Require(true);
  const preview=document.querySelector('#sangriaPreview');
  const btn=document.querySelector('#generateSangria');
  async function load(){
    try{
      const data=await m020Rpc('app_mod020_sangria_summary',{p_token:m020Token()});
      const s=data.summary||{};
      const msg=`SANGRIA BLINDERS - ${s.date}
Horário padrão: 00:00

Depósitos totais: ${s.depositsTotalLabel}
Ganhos em % das mesas: ${s.tableFeesLabel}
Ganhos em jogos individuais: ${s.soloGamesProfitLabel}
Contas criadas hoje: ${s.accountsToday}

Banco EMSHBY: ${s.emshbyBalanceLabel}`;
      preview.textContent=msg;
      btn.href=m020Wa(msg);
    }catch(e){m020Status(m020Esc(e.message),'error')}
  }
  document.querySelector('#registerSangria')?.addEventListener('click',async()=>{
    try{
      const data=await m020Rpc('app_mod020_register_sangria',{p_token:m020Token()});
      m020Status('Sangria registrada. Envie a mensagem ao admin.','success');
      load();
    }catch(e){m020Status(m020Esc(e.message),'error')}
  });
  load();
}

function m020BootRules(){
  if(document.body.dataset.page!=='mod020-rules') return;
  const list=document.querySelector('#rulesList');
  const rules=[
    ['Blackjack','Mesa com 2 jogadores. Mestre aceita apostas. O pote recebe as apostas. Vencedor leva pote - 5% de comissão da casa.'],
    ['Bingo','Mesa com até 5 jogadores. Mestre aceita apostas e inicia. Vencedor leva pote - 5% de comissão.'],
    ['Dados','Mesa com 4 jogadores. Maior resultado vence. Vencedor leva pote - 5% de comissão.'],
    ['Roleta','Mesa com até 5 jogadores. Mestre inicia rodada. Vencedor leva pote - 5% de comissão.'],
    ['Slots','Individual contra CPU. Aposta debitada. Vitória paga 2x; derrota fica no Banco EMSHBY.'],
    ['Crash','Individual contra CPU. Aposta debitada. Vitória paga 2x; derrota fica no Banco EMSHBY.'],
    ['Memória','Individual contra CPU. Aposta debitada. Vitória paga 2x; derrota fica no Banco EMSHBY.'],
    ['Mines','Individual contra CPU. Aposta debitada. Vitória paga 2x; derrota fica no Banco EMSHBY.'],
    ['Plinko','Individual contra CPU. Aposta debitada. Vitória paga 2x; derrota fica no Banco EMSHBY.'],
    ['Coin Flip','Individual contra CPU. Aposta debitada. Vitória paga 2x; derrota fica no Banco EMSHBY.'],
    ['Baccarat','Individual contra CPU. Aposta debitada. Vitória paga 2x; derrota fica no Banco EMSHBY.'],
    ['Banco EMSHBY','Recebe depósitos contabilizados, perdas dos jogos individuais e comissão de 5% das mesas.']
  ];
  list.innerHTML=rules.map(r=>`<article class="mod020-rule"><h3>${m020Esc(r[0])}</h3><p>${m020Esc(r[1])}</p></article>`).join('');
}

function m020PatchAdminMenus(){
  if(!m020IsAdmin()) return;
  const targets=document.querySelectorAll('.nav, .engtech-nav');
  targets.forEach(t=>{
    if(!t.querySelector('a[href="/owner/system-control.html"]')){
      t.insertAdjacentHTML('beforeend',`
        <a class="btn" href="/owner/system-control.html" data-admin-only>Sistema</a>
        <a class="btn" href="/owner/sangria.html" data-admin-only>Sangria</a>
      `);
    }
  });
}

function m020PatchMemberMenus(){
  const lobby=document.querySelector('body[data-page="start"] .grid');
  if(lobby && !lobby.querySelector('a[href="/member/chat.html"]')){
    lobby.insertAdjacentHTML('beforeend',`
      <a class="card icon-card menu-tile" href="/member/chat.html"><img class="icon-mini" src="/assets/ui/icons/chat.svg" onerror="this.src='/assets/ui/icons/bell.svg'"><h2>Chat</h2><p>Chat e amigos.</p></a>
      <a class="card icon-card menu-tile" href="/rules/index.html"><img class="icon-mini" src="/assets/ui/icons/history.svg"><h2>Regras</h2><p>Regras dos jogos.</p></a>
    `);
  }
}

document.addEventListener('DOMContentLoaded',()=>{
  m020CheckAccessOnLoginPage();
  m020PatchLoginSubmit();
  m020PatchGameRender();
  m020PatchAdminMenus();
  m020PatchMemberMenus();
  m020BootChat();
  m020BootAdminSystem();
  m020BootSangria();
  m020BootRules();
});
