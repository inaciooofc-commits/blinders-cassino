/*
  Blinders Cassino — 0.3 Oficial Estável
  Inclui módulos de estabilidade, banco, jogos, bônus, segurança, chat, clãs, loja e relatórios.
*/
const OFF_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const OFF_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const OFF_TOKEN='BLINDERS_TOKEN_V25';
const OFF_MEMBER='BLINDERS_MEMBER_V25';
const OFF_WA='5511951289502';

function offToken(){return localStorage.getItem(OFF_TOKEN)}
function offMember(){try{return JSON.parse(localStorage.getItem(OFF_MEMBER)||'null')}catch{return null}}
function offAdmin(){const m=offMember();return !!m&&['admin','owner'].includes(m.role)}
function offEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function offStatus(msg,type=''){const b=document.querySelector('#statusBox');if(b){b.className='status '+type;b.innerHTML=msg}}
function offWA(msg){return `https://wa.me/${OFF_WA}?text=${encodeURIComponent(msg)}`}
async function offRpc(name,params={}){
  const res=await fetch(`${OFF_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{apikey:OFF_KEY,Authorization:`Bearer ${OFF_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text();let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok)throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}
function offRequire(admin=false){
  const m=offMember();
  if(!m||!offToken()){location.href=admin?'/owner/login.html':'/member/login.html';return null}
  if(admin&&!offAdmin()){location.href='/member/start.html';return null}
  return m;
}
function offCleanMember(){
  const isAdmin=offAdmin();
  document.body.classList.toggle('official-admin',isAdmin);
  document.body.classList.toggle('official-member-clean',!isAdmin);
  if(!isAdmin){
    document.querySelectorAll('a[href^="/owner/"], [data-admin-only], .admin-only, .engtech-admin-sep, .debug, .system-debug, [data-debug], .dev-info, .sql-info, .version-info, .engine-label, .tech-label, .internal-status').forEach(el=>el.remove());
    document.body.innerHTML=document.body.innerHTML.replaceAll('ENGTech','').replaceAll('EGNTech','').replaceAll('SQL','').replaceAll('Módulo 0','').replaceAll('Módulo 0.1.0','').replaceAll('Módulo 0.2.0','').replaceAll('Módulo 0.3.0','');
  }
  if(location.pathname.startsWith('/owner/')&&!isAdmin&&!location.pathname.includes('/owner/login')){
    location.href='/member/start.html';
  }
}
function offStage(game){
  const g=String(game||'roleta').toLowerCase();
  const map={
    roleta:`<div class="mod0-stage-roleta"><div class="wheel"></div></div>`,
    blackjack:`<div class="mod0-stage-blackjack"><div class="cards"><div class="cardx">A♠</div><div class="cardx">10♥</div><div class="cardx">K♣</div></div></div>`,
    dados:`<div class="mod0-stage-dados"><div class="dices"><div class="dicex">⚄</div><div class="dicex">⚂</div></div></div>`,
    slots:`<div class="mod0-stage-slots"><div class="reels"><div class="reelx">7</div><div class="reelx">★</div><div class="reelx">B</div></div></div>`,
    crash:`<div class="mod0-stage-crash"><div class="rocket">🚀</div></div>`,
    memoria:`<div class="mod0-stage-memoria"><div class="cards"><div class="cardx">?</div><div class="cardx">★</div><div class="cardx">?</div><div class="cardx">★</div></div></div>`,
    mines:`<div class="mod0-stage-mines"><div class="gridmines"><div class="cell safe">♦</div><div class="cell mine">✖</div><div class="cell safe">♠</div><div class="cell safe">♥</div><div class="cell safe">♣</div><div class="cell safe">♦</div><div class="cell mine">✖</div><div class="cell safe">♠</div></div></div>`,
    plinko:`<div class="mod0-stage-plinko"><div class="pins">${Array.from({length:21}).map((_,i)=>`<div class="${i===10?'chip':'pin'}"></div>`).join('')}</div></div>`,
    coinflip:`<div class="mod0-stage-coinflip"><div class="coin">🪙</div></div>`,
    baccarat:`<div class="mod0-stage-baccarat"><div class="cards"><div class="cardx">9♦</div><div class="cardx">2♣</div><div class="cardx">8♠</div><div class="cardx">A♥</div></div></div>`
  };
  return map[g]||map.slots;
}
function offPatchLobby(){
  if(location.pathname!='/member/start.html')return;
  const app=document.querySelector('main.app');
  if(!app||app.querySelector('.official-dashboard'))return;
  const hero=document.createElement('section');
  hero.className='official-dashboard';
  hero.innerHTML=`
    <article class="official-hero">
      <h1>Blinders Cassino</h1>
      <p>Jogue, converse, use o Banco IRIS, participe de clãs e acompanhe tudo pelo seu histórico.</p>
      <div class="actions">
        <a class="btn" href="/play/index.html">Jogar</a>
        <a class="btn ghost" href="/iris/index.html">Banco IRIS</a>
        <a class="btn ghost" href="/member/bonus.html">Bônus</a>
      </div>
    </article>
    <aside class="official-side">
      <article class="card stable-mini-card"><h2>Banco IRIS</h2><p>Depósitos, saques, transferências e histórico organizados.</p></article>
      <article class="card stable-mini-card"><h2>Comunidade</h2><p>Chat, amigos por ID, clãs, eventos e rankings.</p></article>
    </aside>`;
  app.insertBefore(hero, app.children[1]||null);
}
function offPatchMenus(){
  const lobby=document.querySelector('body[data-page="start"] .grid');
  if(lobby&&!lobby.querySelector('a[href="/member/status.html"]')){
    lobby.insertAdjacentHTML('beforeend',`
      <a class="card icon-card menu-tile" href="/member/status.html"><img class="icon-mini" src="/assets/ui/icons/status.svg"><h2>Meu status</h2><p>Resumo da conta.</p></a>
      <a class="card icon-card menu-tile" href="/events/index.html"><img class="icon-mini" src="/assets/iconpack/gold-chip.svg"><h2>Eventos</h2><p>Bônus e missões.</p></a>
      <a class="card icon-card menu-tile" href="/leaderboard/index.html"><img class="icon-mini" src="/assets/iconpack/trophy.svg"><h2>Ranking</h2><p>Maiores vitórias.</p></a>
      <a class="card icon-card menu-tile" href="/member/inventory.html"><img class="icon-mini" src="/assets/ui/icons/shop.svg"><h2>Inventário</h2><p>Itens seguros.</p></a>
    `);
  }
  if(offAdmin()){
    document.querySelectorAll('.nav,.engtech-nav').forEach(n=>{
      if(!n.querySelector('a[href="/owner/official-dashboard.html"]')){
        n.insertAdjacentHTML('afterbegin',`
          <a class="btn" href="/owner/official-dashboard.html" data-admin-only>Painel oficial</a>
          <a class="btn" href="/owner/backups.html" data-admin-only>Backups</a>
          <a class="btn" href="/owner/audit.html" data-admin-only>Auditoria</a>
          <a class="btn" href="/owner/health.html" data-admin-only>Saúde</a>
          <a class="btn" href="/owner/reports-center.html" data-admin-only>Relatórios</a>
        `);
      }
    });
  }
}
function offBootGame(){
  if(document.body.dataset.page!=='official-game')return;
  offRequire(false);
  const game=(new URLSearchParams(location.search).get('game')||'roleta').toLowerCase();
  document.querySelector('#gameTitle').textContent=game.toUpperCase();
  document.querySelector('#officialStage').innerHTML=offStage(game);
  offRpc('app_official03_game_rule',{p_game_key:game}).then(d=>{
    const r=d.rule||{};
    document.querySelector('#gameRule').innerHTML=`<p><strong>Regra:</strong> ${offEsc(r.payoutRule||'Vitória paga conforme regra do jogo.')}</p><p><strong>Banco:</strong> ${offEsc(r.bankRule||'Prêmios dependem do cofre EMSHBY.')}</p>`;
  }).catch(()=>{});
  document.querySelector('#officialBetForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const amount=String(new FormData(e.currentTarget).get('amount')||'').trim();
    const stage=document.querySelector('#officialStage'), out=document.querySelector('#officialResult');
    stage.innerHTML=`<div class="official-render"><div><div class="official-render-title">Renderizando...</div><p>Aguarde o resultado da partida</p><div class="official-loader"></div></div></div>`;
    out.innerHTML='';
    const start=Date.now();
    try{
      const data=await offRpc('app_v25_play_game',{p_token:offToken(),p_game_key:game,p_amount:amount});
      setTimeout(()=>{
        const r=data.result||{};
        stage.innerHTML=offStage(game);
        out.innerHTML=`<div class="status ${r.outcome==='win'?'success':'error'}">
          <strong>${r.outcome==='win'?'Você ganhou!':'Resultado'}</strong><br>
          ${offEsc(r.message)}<br>
          Aposta: ${offEsc(r.betLabel)}<br>
          Prêmio: ${offEsc(r.prizeLabel)}<br>
          Saldo: ${offEsc(r.balanceLabel)}<br>
          TX: ${offEsc(r.txCode)}<br>
          Astral: ${offEsc(r.astralCode)}
        </div>`;
      },Math.max(0,2400-(Date.now()-start)));
    }catch(err){
      setTimeout(()=>{
        stage.innerHTML=offStage(game);
        out.innerHTML=`<div class="status error">${offEsc(err.message)}</div>`;
      },Math.max(0,1100-(Date.now()-start)));
    }
  });
}
function offBootAdminDashboard(){
  if(document.body.dataset.page!=='official-admin-dashboard')return;
  offRequire(true);
  offRpc('app_official03_admin_overview',{p_token:offToken()}).then(d=>{
    const s=d.summary||{};
    document.querySelector('#officialKpis').innerHTML=[
      ['Cofre EMSHBY',s.vaultLabel],
      ['Depósitos hoje',s.depositsTodayLabel],
      ['Comissão mesas',s.tableFeesLabel],
      ['Jogos individuais',s.soloProfitLabel],
      ['Contas hoje',s.accountsToday],
      ['Erros abertos',s.openErrors],
      ['Modo seguro',s.safeMode?'Ativo':'Desativado'],
      ['Status',s.siteStatus]
    ].map(x=>`<article class="card official-kpi"><span>${offEsc(x[0])}</span><strong>${offEsc(x[1]??0)}</strong></article>`).join('');
  }).catch(e=>offStatus(offEsc(e.message),'error'));
}
function offBootSimpleRpcPage(page, fn, target, renderer){
  if(document.body.dataset.page!==page)return;
  offRequire(page.startsWith('official-admin'));
  offRpc(fn,{p_token:offToken()}).then(d=>{document.querySelector(target).innerHTML=renderer(d)}).catch(e=>offStatus(offEsc(e.message),'error'));
}
function offBootAdminForms(){
  if(document.body.dataset.page==='official-backups'){
    offRequire(true);
    document.querySelector('#backupBtn')?.addEventListener('click',async()=>{
      try{const d=await offRpc('app_official03_create_backup',{p_token:offToken(),p_label:'Backup manual'});offStatus(`Backup criado: ${offEsc(d.backupCode)}`,'success')}catch(e){offStatus(offEsc(e.message),'error')}
    });
    document.querySelector('#safeModeBtn')?.addEventListener('click',async()=>{try{await offRpc('app_official03_toggle_safe_mode',{p_token:offToken(),p_enabled:true});offStatus('Modo seguro ativado.','success')}catch(e){offStatus(offEsc(e.message),'error')}});
    document.querySelector('#safeModeOffBtn')?.addEventListener('click',async()=>{try{await offRpc('app_official03_toggle_safe_mode',{p_token:offToken(),p_enabled:false});offStatus('Modo seguro desativado.','success')}catch(e){offStatus(offEsc(e.message),'error')}});
  }
  if(document.body.dataset.page==='official-reports'){
    offRequire(true);
    document.querySelector('#exportReportBtn')?.addEventListener('click',async()=>{
      try{
        const d=await offRpc('app_official03_daily_report',{p_token:offToken()});
        const txt=d.message||'Relatório indisponível';
        document.querySelector('#reportText').textContent=txt;
        document.querySelector('#reportWhats').href=offWA(txt);
      }catch(e){offStatus(offEsc(e.message),'error')}
    });
  }
}
document.addEventListener('DOMContentLoaded',()=>{
  offCleanMember();
  offPatchLobby();
  offPatchMenus();
  offBootGame();
  offBootAdminDashboard();
  offBootAdminForms();
  offBootSimpleRpcPage('official-member-status','app_official03_member_home','#memberStatusBox',d=>{
    const s=d.home||{};
    return [
      ['Saldo',s.balanceLabel],
      ['ID amigo',s.friendCode],
      ['Clã',s.clanName||'Nenhum'],
      ['Conquistas',s.achievements||0]
    ].map(x=>`<article class="card official-kpi"><span>${offEsc(x[0])}</span><strong>${offEsc(x[1]??'-')}</strong></article>`).join('');
  });
  offBootSimpleRpcPage('official-leaderboard','app_official03_leaderboard','#leaderboardBox',d=>{
    return `<table class="official-table"><thead><tr><th>#</th><th>Membro</th><th>Ganhos</th><th>Apostas</th></tr></thead><tbody>${(d.rows||[]).map((r,i)=>`<tr><td>${i+1}</td><td>${offEsc(r.nick)}</td><td>${offEsc(r.totalWinLabel)}</td><td>${offEsc(r.totalBetLabel)}</td></tr>`).join('')}</tbody></table>`;
  });
  offBootSimpleRpcPage('official-events','app_official03_events','#eventsBox',d=>{
    return (d.events||[]).map(e=>`<article class="card"><h2>${offEsc(e.title)}</h2><p>${offEsc(e.description)}</p><span class="official-pill">${offEsc(e.kind)}</span></article>`).join('')||'<article class="card"><h2>Sem eventos ativos</h2></article>';
  });
  offBootSimpleRpcPage('official-inventory','app_official03_inventory','#inventoryBox',d=>{
    return (d.items||[]).map(i=>`<article class="card"><h2>${offEsc(i.name||i.itemKey)}</h2><p>${offEsc(i.category||'Item')}</p><span class="official-pill">${offEsc(i.rarity||'comum')}</span></article>`).join('')||'<article class="card"><h2>Inventário vazio</h2><p>Resgate bônus ou compre itens na loja.</p></article>';
  });
  offBootSimpleRpcPage('official-admin-health','app_official03_health','#healthBox',d=>{
    return `<pre class="status">${offEsc(JSON.stringify(d.health||{},null,2))}</pre>`;
  });
  offBootSimpleRpcPage('official-admin-audit','app_official03_audit','#auditBox',d=>{
    return `<table class="official-table"><thead><tr><th>Hora</th><th>Ação</th><th>Admin</th><th>Info</th></tr></thead><tbody>${(d.rows||[]).map(r=>`<tr><td>${offEsc(r.createdAt)}</td><td>${offEsc(r.eventKey)}</td><td>${offEsc(r.actor)}</td><td>${offEsc(r.message)}</td></tr>`).join('')}</tbody></table>`;
  });
  setTimeout(offCleanMember,250);
  setTimeout(offCleanMember,900);
});
