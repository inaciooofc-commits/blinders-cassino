/*
  Blinders 0.3.2 — Jogos reais no navegador.
  Cada jogo tem estado, regra, ações e resultado próprio.
  O banco ainda valida saldo/cofre/registro final via Supabase.
*/
const RG_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const RG_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const RG_TOKEN='BLINDERS_TOKEN_V25';
function rgToken(){return localStorage.getItem(RG_TOKEN)}
function rgEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
async function rgRpc(name,params={}){
  const res=await fetch(`${RG_URL}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:RG_KEY,Authorization:`Bearer ${RG_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(params)});
  const text=await res.text();let data=null;try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok)throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}
const $=(s)=>document.querySelector(s);
const RG={
  game:'slots', bet:'', started:false, finished:false, win:false, payoutMult:0,
  board:null, panel:null, logEl:null,
  log(msg){ if(this.logEl){this.logEl.insertAdjacentHTML('beforeend',`<div>• ${rgEsc(msg)}</div>`);this.logEl.scrollTop=this.logEl.scrollHeight}},
  setBoard(html){this.board.innerHTML=`<div class="real-game-inside">${html}</div>`},
  setActions(html){$('#realActions').innerHTML=html},
  async settle(outcome,payoutMult,details={}){
    if(this.finished)return;
    this.finished=true; this.win=outcome==='win'; this.payoutMult=payoutMult;
    this.setActions('');
    try{
      const data=await rgRpc('app_real032_settle_game',{p_token:rgToken(),p_game_key:this.game,p_amount:this.bet,p_outcome:outcome,p_payout_mult:payoutMult,p_details:details});
      const r=data.result||{};
      $('#realResult').innerHTML=`<div class="status ${outcome==='win'?'success':'error'}"><strong>${outcome==='win'?'Vitória!':'Resultado'}</strong><br>${rgEsc(r.message)}<br>Aposta: ${rgEsc(r.betLabel)}<br>Prêmio: ${rgEsc(r.prizeLabel)}<br>Saldo: ${rgEsc(r.balanceLabel)}<br>TX: ${rgEsc(r.txCode)}<br>Astral: ${rgEsc(r.astralCode)}</div>`;
      this.log(r.message||'Partida finalizada.');
    }catch(err){
      $('#realResult').innerHTML=`<div class="status error">${rgEsc(err.message)}</div>`;
      this.log('Erro ao registrar resultado no banco.');
    }
  }
};
function rand(n){return Math.floor(Math.random()*n)}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=rand(i+1);[a[i],a[j]]=[a[j],a[i]]}return a}
function cardValue(c){let r=c.slice(0,-1);if(['J','Q','K'].includes(r))return 10;if(r==='A')return 11;return Number(r)}
function handValue(hand){let total=hand.reduce((s,c)=>s+cardValue(c),0);let aces=hand.filter(c=>c[0]==='A').length;while(total>21&&aces>0){total-=10;aces--}return total}
function makeDeck(){const suits=['♠','♥','♦','♣'];const ranks=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];return shuffle(ranks.flatMap(r=>suits.map(s=>r+s)))}
function cardHtml(c){const red=c.includes('♥')||c.includes('♦');return `<div class="real-card ${red?'red':''}">${c}</div>`}
const Games={
  blackjack:{
    start(){
      RG.deck=makeDeck(); RG.player=[RG.deck.pop(),RG.deck.pop()]; RG.dealer=[RG.deck.pop(),RG.deck.pop()];
      RG.log('Cartas distribuídas. Você pode pedir carta ou parar.');
      this.render(false);
      RG.setActions(`<button class="btn" id="hitBtn">Pedir carta</button><button class="btn ghost" id="standBtn">Parar</button>`);
      $('#hitBtn').onclick=()=>this.hit(); $('#standBtn').onclick=()=>this.stand();
    },
    render(reveal=false){
      const p=handValue(RG.player), d=reveal?handValue(RG.dealer):'?';
      RG.setBoard(`<section class="real-table-section"><h2>Dealer</h2><div class="real-card-hand">${reveal?RG.dealer.map(cardHtml).join(''):`${cardHtml(RG.dealer[0])}<div class="real-card back">?</div>`}</div><div class="real-score">Pontos: ${d}</div><h2>Você</h2><div class="real-card-hand">${RG.player.map(cardHtml).join('')}</div><div class="real-score">Pontos: ${p}</div></section>`);
    },
    hit(){RG.player.push(RG.deck.pop());this.render(false);const p=handValue(RG.player);RG.log('Você pediu carta. Pontos: '+p);if(p>21){this.render(true);RG.settle('loss',0,{player:RG.player,dealer:RG.dealer,reason:'bust'})}},
    stand(){while(handValue(RG.dealer)<17)RG.dealer.push(RG.deck.pop());this.render(true);const p=handValue(RG.player),d=handValue(RG.dealer);RG.log(`Você parou com ${p}. Dealer ficou com ${d}.`);if(d>21||p>d)RG.settle('win',2,{player:RG.player,dealer:RG.dealer});else if(p===d)RG.settle('push',1,{player:RG.player,dealer:RG.dealer});else RG.settle('loss',0,{player:RG.player,dealer:RG.dealer})}
  },
  roleta:{
    start(){
      RG.choice='red'; RG.setBoard(`<div class="real-pointer"></div><div class="real-wheel" id="wheel"></div><div class="real-game-title-row"><span class="real-chip">0</span><span class="real-chip">1-36</span><span class="real-chip">R/P</span></div>`);
      RG.setActions(`<select id="rouletteBet"><option value="red">Vermelho</option><option value="black">Preto</option><option value="even">Par</option><option value="odd">Ímpar</option><option value="green">Zero</option></select><button class="btn" id="spinBtn">Girar roleta</button>`);
      $('#spinBtn').onclick=()=>this.spin();
      RG.log('Escolha a aposta e gire a roleta.');
    },
    spin(){
      const bet=$('#rouletteBet').value; const n=rand(37); const color=n===0?'green':(n%2?'red':'black');
      const deg=1440 + (360 - (n/37)*360);
      $('#wheel').style.transform=`rotate(${deg}deg)`;
      RG.log('Roleta girando...');
      setTimeout(()=>{
        const win=(bet==='green'&&n===0)||(bet==='red'&&color==='red')||(bet==='black'&&color==='black')||(bet==='even'&&n!==0&&n%2===0)||(bet==='odd'&&n%2===1);
        RG.log(`Resultado: ${n} ${color}.`);
        RG.settle(win?'win':'loss', bet==='green'&&win?14:win?2:0,{number:n,color,bet});
      },3600);
    }
  },
  dados:{
    start(){RG.setBoard(`<div class="real-dice-row"><div class="real-die" id="d1">⚀</div><div class="real-die" id="d2">⚀</div></div><p>Você vence com soma 7 ou mais.</p>`);RG.setActions(`<button class="btn" id="rollBtn">Rolar dados</button>`);$('#rollBtn').onclick=()=>this.roll();RG.log('Role os dados. 7 ou mais vence.')},
    roll(){const faces=['⚀','⚁','⚂','⚃','⚄','⚅'];$('#d1').classList.add('rolling');$('#d2').classList.add('rolling');let t=setInterval(()=>{$('#d1').textContent=faces[rand(6)];$('#d2').textContent=faces[rand(6)]},90);setTimeout(()=>{clearInterval(t);let a=rand(6)+1,b=rand(6)+1;$('#d1').classList.remove('rolling');$('#d2').classList.remove('rolling');$('#d1').textContent=faces[a-1];$('#d2').textContent=faces[b-1];RG.log(`Dados: ${a}+${b} = ${a+b}.`);RG.settle(a+b>=7?'win':'loss',a+b>=7?2:0,{d1:a,d2:b,sum:a+b})},1600)}
  },
  bingo:{
    start(){RG.numbers=shuffle([...Array(75)].map((_,i)=>i+1));RG.drawn=[];RG.card=shuffle([...Array(75)].map((_,i)=>i+1)).slice(0,25);RG.card[12]='FREE';this.render();RG.setActions(`<button class="btn" id="drawBtn">Sortear bola</button>`);$('#drawBtn').onclick=()=>this.draw();RG.log('Complete uma linha, coluna ou diagonal em até 18 bolas.')},
    render(){RG.setBoard(`<div><div class="real-bingo-card">${RG.card.map((n,i)=>`<div class="real-bingo-cell ${(n==='FREE'||RG.drawn.includes(n))?'marked':''}">${n}</div>`).join('')}</div><p>Bolas: ${RG.drawn.slice(-6).join(', ')||'-'}</p></div>`)},
    hasBingo(){const m=i=>RG.card[i]==='FREE'||RG.drawn.includes(RG.card[i]);const lines=[[0,1,2,3,4],[5,6,7,8,9],[10,11,12,13,14],[15,16,17,18,19],[20,21,22,23,24],[0,5,10,15,20],[1,6,11,16,21],[2,7,12,17,22],[3,8,13,18,23],[4,9,14,19,24],[0,6,12,18,24],[4,8,12,16,20]];return lines.some(line=>line.every(m))},
    draw(){const n=RG.numbers.pop();RG.drawn.push(n);this.render();RG.log('Bola sorteada: '+n);if(this.hasBingo())RG.settle('win',2,{drawn:RG.drawn});else if(RG.drawn.length>=18)RG.settle('loss',0,{drawn:RG.drawn})}
  },
  slots:{
    start(){RG.setBoard(`<div class="real-slots"><div class="real-reel" id="r1">7</div><div class="real-reel" id="r2">★</div><div class="real-reel" id="r3">B</div></div><p>Três símbolos iguais pagam prêmio.</p>`);RG.setActions(`<button class="btn" id="slotBtn">Girar</button>`);$('#slotBtn').onclick=()=>this.spin();RG.log('Gire os rolos.')},
    spin(){const sy=['7','★','B','♦','♠','🍒'];['r1','r2','r3'].forEach(id=>$('#'+id).classList.add('spin'));let t=setInterval(()=>['r1','r2','r3'].forEach(id=>$('#'+id).textContent=sy[rand(sy.length)]),80);setTimeout(()=>{clearInterval(t);const res=[sy[rand(sy.length)],sy[rand(sy.length)],sy[rand(sy.length)]];['r1','r2','r3'].forEach((id,i)=>{$('#'+id).classList.remove('spin');$('#'+id).textContent=res[i]});const win=res.every(x=>x===res[0]);RG.log('Rolos: '+res.join(' '));RG.settle(win?'win':'loss',win?3:0,{reels:res})},1700)}
  },
  memoria:{
    start(){const vals=shuffle(['A','A','B','B','C','C','D','D','E','E','F','F','G','G','H','H']);RG.mem=vals.map((v,i)=>({v,i,open:false,done:false}));RG.pick=[];RG.moves=0;this.render();RG.log('Encontre todos os pares em até 14 jogadas.')},
    render(){RG.setBoard(`<div class="real-memory-grid">${RG.mem.map(c=>`<button class="real-memory-card ${c.open?'open':''} ${c.done?'done':''}" data-i="${c.i}">${(c.open||c.done)?c.v:'?'}</button>`).join('')}</div><p>Jogadas: ${RG.moves}/14</p>`);document.querySelectorAll('.real-memory-card').forEach(b=>b.onclick=()=>this.flip(Number(b.dataset.i)))},
    flip(i){const c=RG.mem[i];if(c.done||c.open||RG.pick.length>=2)return;c.open=true;RG.pick.push(c);this.render();if(RG.pick.length===2){RG.moves++;setTimeout(()=>{const [a,b]=RG.pick;if(a.v===b.v){a.done=b.done=true;RG.log('Par encontrado: '+a.v)}else{a.open=b.open=false;RG.log('Não foi par.')}RG.pick=[];if(RG.mem.every(x=>x.done))RG.settle('win',2,{moves:RG.moves});else if(RG.moves>=14)RG.settle('loss',0,{moves:RG.moves});else this.render()},700)}},
  },
  mines:{
    start(){RG.mineSet=new Set();while(RG.mineSet.size<3)RG.mineSet.add(rand(16));RG.safe=0;this.render();RG.log('Abra 5 casas seguras sem achar bomba.')},
    render(){RG.setBoard(`<div class="real-mines-grid">${[...Array(16)].map((_,i)=>`<button class="real-mine-cell" data-i="${i}">?</button>`).join('')}</div><p>Seguras: ${RG.safe}/5</p>`);document.querySelectorAll('.real-mine-cell').forEach(b=>b.onclick=()=>this.open(Number(b.dataset.i),b))},
    open(i,b){if(b.disabled)return;b.disabled=true;if(RG.mineSet.has(i)){b.textContent='✖';b.classList.add('bomb');RG.log('Bomba encontrada.');RG.settle('loss',0,{safe:RG.safe})}else{b.textContent='♦';b.classList.add('safe');RG.safe++;RG.log('Casa segura.');if(RG.safe>=5)RG.settle('win',2,{safe:RG.safe})}}
  },
  crash:{
    start(){RG.mult=1;RG.crashAt=1.25+Math.random()*3.2;RG.cashed=false;RG.setBoard(`<div><div class="real-multiplier" id="mult">1.00x</div><div class="real-crash-graph"><div class="real-crash-line" id="crashDot"></div></div></div>`);RG.setActions(`<button class="btn" id="cashBtn">Retirar</button>`);$('#cashBtn').onclick=()=>this.cash();RG.timer=setInterval(()=>this.tick(),170);RG.log('Retire antes de crashar.')},
    tick(){RG.mult+=0.08;$('#mult').textContent=RG.mult.toFixed(2)+'x';const x=Math.min(360,(RG.mult-1)*110),y=Math.min(190,(RG.mult-1)*70);$('#crashDot').style.left=(10+x)+'px';$('#crashDot').style.bottom=(10+y)+'px';if(RG.mult>=RG.crashAt&&!RG.cashed){clearInterval(RG.timer);RG.log('Crash em '+RG.crashAt.toFixed(2)+'x');RG.settle('loss',0,{crashAt:RG.crashAt})}},
    cash(){RG.cashed=true;clearInterval(RG.timer);RG.log('Você retirou em '+RG.mult.toFixed(2)+'x');RG.settle('win',Math.min(3,RG.mult),{cashout:RG.mult,crashAt:RG.crashAt})}
  },
  plinko:{
    start(){let pins='';for(let r=0;r<6;r++){for(let c=0;c<=r;c++){pins+=`<span class="real-pin" style="left:${150+(c-r/2)*44}px;top:${45+r*38}px"></span>`}}RG.setBoard(`<div class="real-plinko" id="plinko">${pins}<span class="real-ball" id="ball" style="left:154px;top:10px"></span></div><p>A bola cai em multiplicadores diferentes.</p>`);RG.setActions(`<button class="btn" id="dropBtn">Soltar bola</button>`);$('#dropBtn').onclick=()=>this.drop();RG.log('Solte a bola.')},
    drop(){let x=154,y=10,steps=0;let timer=setInterval(()=>{steps++;x+=Math.random()>0.5?22:-22;y+=28;$('#ball').style.left=x+'px';$('#ball').style.top=y+'px';if(steps>=9){clearInterval(timer);const center=Math.abs(x-154);const win=center>50;RG.log('Bola caiu. Distância: '+Math.round(center));RG.settle(win?'win':'loss',win?2:0,{x,center})}},180)}
  },
  coinflip:{
    start(){RG.setBoard(`<div><div class="real-coin" id="coin">🪙</div><p>Escolha cara ou coroa.</p></div>`);RG.setActions(`<button class="btn" id="heads">Cara</button><button class="btn ghost" id="tails">Coroa</button>`);$('#heads').onclick=()=>this.flip('heads');$('#tails').onclick=()=>this.flip('tails')},
    flip(choice){let res=Math.random()>0.5?'heads':'tails';$('#coin').style.animation='realCoin .18s linear infinite';setTimeout(()=>{$('#coin').style.animation='none';$('#coin').textContent=res==='heads'?'🙂':'👑';RG.log(`Você escolheu ${choice==='heads'?'cara':'coroa'}. Resultado: ${res==='heads'?'cara':'coroa'}.`);RG.settle(choice===res?'win':'loss',choice===res?2:0,{choice,result:res})},1500)}
  },
  baccarat:{
    start(){const deck=makeDeck();const player=[deck.pop(),deck.pop()],banker=[deck.pop(),deck.pop()];const val=h=>h.reduce((s,c)=>s+Math.min(cardValue(c),10),0)%10;const pv=val(player),bv=val(banker);RG.setBoard(`<section class="real-table-section"><h2>Jogador</h2><div class="real-card-hand">${player.map(cardHtml).join('')}</div><div class="real-score">${pv}</div><h2>Banco</h2><div class="real-card-hand">${banker.map(cardHtml).join('')}</div><div class="real-score">${bv}</div></section>`);RG.setActions(`<button class="btn" id="betPlayer">Apostar Jogador</button><button class="btn ghost" id="betBanker">Apostar Banco</button>`);$('#betPlayer').onclick=()=>this.finish('player',player,banker,pv,bv);$('#betBanker').onclick=()=>this.finish('banker',player,banker,pv,bv);RG.log('Escolha jogador ou banco.')},
    finish(choice,player,banker,pv,bv){const result=pv===bv?'tie':pv>bv?'player':'banker';RG.log(`Resultado: ${result}.`);RG.settle(choice===result?'win':'loss',choice===result?2:0,{choice,result,player,banker})}
  }
};
function bootRealGame(){
  if(document.body.dataset.page!=='real-game')return;
  RG.game=(new URLSearchParams(location.search).get('game')||'slots').toLowerCase();
  RG.board=$('#realBoard'); RG.panel=$('#realPanel'); RG.logEl=$('#realLog');
  $('#realGameTitle').textContent=RG.game.toUpperCase();
  $('#realStartForm').addEventListener('submit',async e=>{
    e.preventDefault();
    RG.bet=String(new FormData(e.currentTarget).get('amount')||'').trim();
    $('#realResult').innerHTML='';
    try{
      await rgRpc('app_real032_validate_start',{p_token:rgToken(),p_game_key:RG.game,p_amount:RG.bet});
      RG.started=true;RG.finished=false;
      e.currentTarget.classList.add('hidden');
      RG.log('Aposta validada. Partida iniciada de verdade.');
      (Games[RG.game]||Games.slots).start();
    }catch(err){
      $('#realResult').innerHTML=`<div class="status error">${rgEsc(err.message)}</div>`;
    }
  });
}
document.addEventListener('DOMContentLoaded',bootRealGame);
