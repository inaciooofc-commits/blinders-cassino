const V34_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const V34_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const V34_TOKEN='BLINDERS_TOKEN_V25';
function tk(){return localStorage.getItem(V34_TOKEN)}
function mem(){try{return JSON.parse(localStorage.getItem('BLINDERS_MEMBER_V25')||'null')}catch{return null}}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function st(m,t=''){const b=document.querySelector('#statusBox');if(b){b.className='status '+t;b.innerHTML=m}}
async function rpc(name,params={}){
 const res=await fetch(`${V34_URL}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:V34_KEY,Authorization:`Bearer ${V34_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(params)});
 const text=await res.text();let data=null;try{data=text?JSON.parse(text):null}catch{data=text}
 if(!res.ok)throw new Error(data?.message||data?.hint||text||'Erro');
 return data;
}
function requireLogin(admin=false){
 const m=mem(); if(!m||!tk()){location.href=admin?'/owner/login.html':'/member/login.html';return null}
 if(admin&&!['admin','owner'].includes(m.role)){location.href='/member/start.html';return null}
 return m;
}
function bootBgCarousel(){
 if(document.body.dataset.page==='login'||document.body.dataset.page==='register'||document.body.dataset.page==='owner-login')return;
 const b=document.createElement('div'); b.className='egntec-bg-carousel';
 const imgs=['/assets/backgrounds/smoke-table.svg','/assets/backgrounds/city-gold.svg','/assets/backgrounds/green-room.svg'];
 let i=0; b.style.backgroundImage=`url('${imgs[0]}')`; document.body.prepend(b);
 setInterval(()=>{i=(i+1)%imgs.length;b.style.backgroundImage=`url('${imgs[i]}')`},6000);
}
async function bootShopV34(){
 requireLogin();
 let page=1, totalPages=1, limit=10;
 const list=document.querySelector('#shopList')||document.querySelector('#list');
 const pages=document.querySelector('#shopPages');
 async function load(){
  const data=await rpc('app_v34_shop_items',{p_token:tk(),p_page:page,p_limit:limit});
  totalPages=data.totalPages||1;
  const rows=data.items||[];
  list.innerHTML=rows.map(i=>`<article class="card shop-card">
    <img class="shop-item-icon" src="${esc(i.iconPath)}" onerror="this.src='/assets/iconpack/gold-chip.svg'">
    <h2>${esc(i.name)}</h2>
    <span class="badge">${esc(i.rarity)}</span>
    <p>${esc(i.description)}</p>
    <strong>${esc(i.priceLabel)}</strong>
  </article>`).join('')||'<article class="card"><h2>Loja vazia</h2></article>';
  pages.innerHTML=Array.from({length:totalPages}).map((_,idx)=>`<button class="btn ${idx+1===page?'':'ghost'}" data-page="${idx+1}">${idx+1}</button>`).join('');
 }
 document.addEventListener('click',e=>{const p=e.target?.dataset?.page;if(p){page=Number(p);load()}});
 load().catch(e=>list.innerHTML=`<article class="card"><h2>Erro</h2><p>${esc(e.message)}</p></article>`);
}
function bootShopLimitAdmin(){
 requireLogin(true);
 const form=document.querySelector('#shopLimitForm');
 form?.addEventListener('submit',async e=>{
  e.preventDefault();
  try{
   const fd=new FormData(form);
   await rpc('app_v34_admin_set_shop_limit',{p_token:tk(),p_limit:Number(fd.get('limit')||100)});
   st('Limite da loja salvo.','success');
  }catch(err){st(esc(err.message),'error')}
 });
}
function bootAdminCenter(){
 requireLogin(true);
 rpc('app_v34_admin_center',{p_token:tk()}).then(data=>{
  const s=data.summary||{};
  document.querySelector('#adminSummary').innerHTML=[
   ['Contas pendentes',s.pendingAccounts],
   ['Transferências recentes',s.recentTransfers],
   ['Depósitos pendentes',s.pendingDeposits],
   ['Saques pendentes',s.pendingWithdraws],
   ['Clãs',s.clans]
  ].map(x=>`<article class="card admin-menu-card"><h2>${x[0]}</h2><div class="kpi">${x[1]||0}</div></article>`).join('');
 }).catch(e=>st(esc(e.message),'error'));
}
function bootAdminConfirmations(){
 requireLogin(true);
 const list=document.querySelector('#confirmList');
 async function load(){
  const data=await rpc('app_v34_admin_confirmations',{p_token:tk()});
  const rows=data.items||[];
  list.innerHTML=rows.map(x=>`<article class="card">
   <h2>${esc(x.type)}</h2><p>${esc(x.title)}</p><div class="code">${esc(x.code||x.txCode||'')}</div>
   <button class="btn" data-confirm="${esc(x.id)}" data-kind="${esc(x.kind)}">Confirmar</button>
  </article>`).join('')||'<article class="card"><h2>Nada pendente</h2></article>';
 }
 document.addEventListener('click',async e=>{
  const id=e.target?.dataset?.confirm, kind=e.target?.dataset?.kind;
  if(!id)return;
  try{await rpc('app_v34_admin_confirm_item',{p_token:tk(),p_kind:kind,p_id:id});load()}catch(err){alert(err.message)}
 });
 load();
}
function bootClans(){
 requireLogin();
 const list=document.querySelector('#clanList');
 const form=document.querySelector('#clanForm');
 async function load(){
  const data=await rpc('app_v34_list_clans',{p_token:tk()});
  list.innerHTML=(data.clans||[]).map(c=>`<article class="card">
    <h2>${esc(c.name)}</h2><span class="clan-badge">${esc(c.tag)}</span><p>Líder: ${esc(c.leaderName)}</p><p>Conta: ${esc(c.irisId)}</p><strong>${esc(c.balanceLabel)}</strong>
  </article>`).join('')||'<article class="card"><h2>Sem clãs</h2></article>';
 }
 form?.addEventListener('submit',async e=>{
  e.preventDefault(); const fd=new FormData(form);
  try{
   st('Criando clã...');
   const data=await rpc('app_v34_create_clan',{p_token:tk(),p_name:String(fd.get('name')||''),p_tag:String(fd.get('tag')||'')});
   st(`Clã criado. Conta: ${esc(data.irisId)}. Custo: 15T debitado.`, 'success'); form.reset(); load();
  }catch(err){st(esc(err.message),'error')}
 });
 load();
}
document.addEventListener('DOMContentLoaded',()=>{
 bootBgCarousel();
 const p=document.body.dataset.page;
 if(p==='shop')bootShopV34();
 if(p==='admin-shop-limit')bootShopLimitAdmin();
 if(p==='admin-center')bootAdminCenter();
 if(p==='admin-confirmations')bootAdminConfirmations();
 if(p==='clans')bootClans();
});
