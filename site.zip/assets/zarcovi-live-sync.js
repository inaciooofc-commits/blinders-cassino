/*
  Blinders 0.3.4 — Zarcovi Live Sync
  - Membros veem o saldo Zarcovi cacheado no Supabase.
  - Admin sincroniza a planilha via CSV publicado/Google gviz.
  - EMSHBY é encontrado e aplicado no cofre do Banco IRIS.
*/
const ZLS_URL='https://lbmmqfgcyimijaqnvvpx.supabase.co';
const ZLS_KEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxibW1xZmdjeWltaWphcW52dnB4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MTY1NjQsImV4cCI6MjA5NTk5MjU2NH0._pQTy5TJ-MZ9Ep2dpD4XbLQGqLRkhzsjQCqDseJ9Cto';
const ZLS_TOKEN='BLINDERS_TOKEN_V25';
const ZLS_MEMBER='BLINDERS_MEMBER_V25';
const ZLS_DEFAULT_CSV='https://docs.google.com/spreadsheets/d/1cUVGRl63tyJvxRK-9nlAhnLBdgunEy9OU-sKYNIx83Y/gviz/tq?tqx=out:csv&gid=0';

function zlsToken(){return localStorage.getItem(ZLS_TOKEN)||''}
function zlsMember(){try{return JSON.parse(localStorage.getItem(ZLS_MEMBER)||'null')}catch{return null}}
function zlsAdmin(){const m=zlsMember();return !!m&&['admin','owner'].includes(m.role)}
function zlsEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function zlsStatus(msg,type=''){const b=document.querySelector('#statusBox');if(b){b.className='status '+type;b.innerHTML=msg}}
async function zlsRpc(name,params={}){
  const res=await fetch(`${ZLS_URL}/rest/v1/rpc/${name}`,{
    method:'POST',
    headers:{apikey:ZLS_KEY,Authorization:`Bearer ${ZLS_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(params)
  });
  const text=await res.text();let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok)throw new Error(data?.message||data?.hint||text||'Erro');
  return data;
}
function zlsParseCSV(text){
  const rows=[];let row=[],cur='',q=false;
  for(let i=0;i<text.length;i++){
    const c=text[i],n=text[i+1];
    if(c==='"'&&q&&n==='"'){cur+='"';i++;continue}
    if(c==='"'){q=!q;continue}
    if(c===','&&!q){row.push(cur);cur='';continue}
    if((c==='\n'||c==='\r')&&!q){
      if(c==='\r'&&n==='\n')i++;
      row.push(cur);rows.push(row);row=[];cur='';continue
    }
    cur+=c;
  }
  if(cur.length||row.length){row.push(cur);rows.push(row)}
  return rows.map(r=>r.map(x=>String(x||'').trim()));
}
function zlsNumber(v){
  let s=String(v??'').trim();
  if(!s)return 0;
  s=s.replace(/[^\d,.\-]/g,'');
  if(!s||s==='-')return 0;
  if(s.includes(',')&&s.includes('.')) s=s.replace(/\./g,'').replace(',','.');
  else if(s.includes(',')) s=s.replace(',','.');
  const n=Number(s);
  return Number.isFinite(n)?n:0;
}
function zlsExtractAccounts(rows){
  const out=[], seen=new Set();
  for(let r=0;r<rows.length;r++){
    const row=rows[r].map(x=>String(x||'').trim());
    for(let i=0;i<row.length-1;i++){
      if(row[i].toLowerCase()==='vila' && row[i+1].toUpperCase()==='CONTA'){
        for(let k=r+1;k<rows.length;k++){
          const rr=rows[k];
          if(!rr || rr.length<i+2) continue;
          const kind=String(rr[i]||'').trim();
          const conta=String(rr[i+1]||'').trim().toUpperCase();
          if(!conta) continue;
          if(conta==='CONTA') continue;
          if(!/^[A-Z]{2,}[A-Z0-9]{1,}$/.test(conta)) continue;
          const key=conta+'@'+k;
          if(seen.has(key)) continue;
          seen.add(key);
          out.push({
            sourceRow:k+1,
            kind:kind||'Conta',
            vila:kind||'',
            conta,
            level:zlsNumber(rr[i+2]),
            ryosB:zlsNumber(rr[i+3]),
            salarioB:zlsNumber(rr[i+4]),
            cargos:String(rr[i+5]||'').trim(),
            fogo:zlsNumber(rr[i+6]),
            pedra:zlsNumber(rr[i+7]),
            personagem:String(rr[i+8]||'').trim(),
            tesouroB:zlsNumber(rr[i+9]),
            raw:rr.slice(i,i+10)
          });
        }
      }
    }
  }
  const byCode=new Map();
  out.forEach(a=>{
    if(!byCode.has(a.conta) || (a.conta==='EMSHBY')) byCode.set(a.conta,a);
  });
  return [...byCode.values()];
}
async function zlsFetchCSV(url){
  const res=await fetch(url,{cache:'no-store'});
  if(!res.ok)throw new Error('Não consegui ler a planilha. Publique a aba como CSV ou use o campo colar CSV.');
  return await res.text();
}
async function zlsSyncFromCSV(csv, sourceUrl='manual'){
  const rows=zlsParseCSV(csv);
  const accounts=zlsExtractAccounts(rows);
  if(!accounts.length) throw new Error('Nenhuma conta encontrada. Verifique se o CSV contém as colunas Vila, CONTA, Level, Ryos.');
  const chunk=300;
  let total=0, emshby=null;
  for(let i=0;i<accounts.length;i+=chunk){
    const part=accounts.slice(i,i+chunk);
    const data=await zlsRpc('app_zarcovi_live_upsert_accounts',{p_token:zlsToken(),p_source_key:'banco01',p_source_url:sourceUrl,p_accounts:part});
    total+=data.imported||part.length;
    if(data.emshby) emshby=data.emshby;
  }
  return {total, emshby, found:accounts.length};
}
function zlsRenderMemberBalance(data){
  const a=data.account||null, b=data.emshby||null;
  const box=document.createElement('section');
  box.className='zarcovi-live-card';
  box.innerHTML=a?`
    <h2>Saldo no Banco Zarcovi</h2>
    <div class="zarcovi-live-balance">${zlsEsc(a.ryosLabel)}</div>
    <p>Conta: <strong>${zlsEsc(a.accountCode)}</strong> • Vila: ${zlsEsc(a.vila||'-')}</p>
    <p>Personagem: ${zlsEsc(a.personagem||'-')}</p>
    <p>Atualizado: ${zlsEsc(a.syncedAt||'-')}</p>
    ${b?`<p class="zarcovi-emshby stable-clean-note">Banco EMSHBY: <strong>${zlsEsc(b.ryosLabel)}</strong></p>`:''}
  `:`
    <h2>Saldo no Banco Zarcovi</h2>
    <p>Não encontrei sua conta Zarcovi sincronizada ainda.</p>
    ${b?`<p class="zarcovi-emshby stable-clean-note">Banco EMSHBY: <strong>${zlsEsc(b.ryosLabel)}</strong></p>`:''}
  `;
  return box;
}
async function zlsBootMemberBalance(){
  if(location.pathname.startsWith('/owner/'))return;
  if(!zlsToken())return;
  const target=document.querySelector('#memberStatusBox') || document.querySelector('main.app') || document.body;
  try{
    const data=await zlsRpc('app_zarcovi_live_member_balance',{p_token:zlsToken()});
    const card=zlsRenderMemberBalance(data);
    if(target.id==='memberStatusBox') target.insertAdjacentElement('afterend',card);
    else target.insertAdjacentElement('afterbegin',card);
  }catch(e){}
}
async function zlsBootAdminPage(){
  if(document.body.dataset.page!=='zarcovi-live-sync')return;
  if(!zlsAdmin()){location.href='/member/start.html';return}
  const sourceInput=document.querySelector('#zarcoviSourceUrl');
  const log=document.querySelector('#zarcoviLog');
  const paste=document.querySelector('#zarcoviCsvPaste');
  function print(v){log.textContent=typeof v==='string'?v:JSON.stringify(v,null,2)}
  sourceInput.value=ZLS_DEFAULT_CSV;
  try{
    const st=await zlsRpc('app_zarcovi_live_status',{p_token:zlsToken()});
    if(st.source?.sourceUrl) sourceInput.value=st.source.sourceUrl;
    print(st);
  }catch(e){print(e.message)}
  document.querySelector('#saveSourceBtn').onclick=async()=>{
    try{
      const data=await zlsRpc('app_zarcovi_live_set_source',{p_token:zlsToken(),p_source_url:sourceInput.value.trim()||ZLS_DEFAULT_CSV});
      print(data);zlsStatus('Fonte salva.','success');
    }catch(e){zlsStatus(zlsEsc(e.message),'error')}
  };
  document.querySelector('#syncNowBtn').onclick=async()=>{
    try{
      zlsStatus('Sincronizando planilha...');
      const url=sourceInput.value.trim()||ZLS_DEFAULT_CSV;
      const csv=await zlsFetchCSV(url);
      const data=await zlsSyncFromCSV(csv,url);
      print(data);zlsStatus('Sincronização concluída.','success');
    }catch(e){zlsStatus(zlsEsc(e.message),'error');print(e.message)}
  };
  document.querySelector('#syncPasteBtn').onclick=async()=>{
    try{
      zlsStatus('Importando CSV colado...');
      const data=await zlsSyncFromCSV(paste.value,'manual_paste');
      print(data);zlsStatus('CSV importado.','success');
    }catch(e){zlsStatus(zlsEsc(e.message),'error');print(e.message)}
  };
  document.querySelector('#applyEmshbyBtn').onclick=async()=>{
    try{
      const data=await zlsRpc('app_zarcovi_live_apply_emshby',{p_token:zlsToken()});
      print(data);zlsStatus('EMSHBY aplicado ao cofre.','success');
    }catch(e){zlsStatus(zlsEsc(e.message),'error');print(e.message)}
  };
  document.querySelector('#monitorBtn').onclick=()=>{
    zlsStatus('Monitor ativado nesta tela. Enquanto ela ficar aberta, sincroniza a cada 60 segundos.','success');
    setInterval(()=>document.querySelector('#syncNowBtn').click(),60000);
  };
}
function zlsPatchMenu(){
  if(!zlsAdmin())return;
  document.querySelectorAll('.nav,.engtech-nav').forEach(n=>{
    if(!n.querySelector('a[href="/owner/zarcovi-sync.html"]')){
      n.insertAdjacentHTML('afterbegin','<a class="btn" href="/owner/zarcovi-sync.html" data-admin-only>Zarcovi Sync</a>');
    }
  });
}
document.addEventListener('DOMContentLoaded',()=>{
  zlsPatchMenu();
  zlsBootMemberBalance();
  zlsBootAdminPage();
});
